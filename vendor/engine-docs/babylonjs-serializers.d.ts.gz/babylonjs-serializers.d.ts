
declare namespace BABYLON {
    /** Pure barrel — re-exports only side-effect-free modules */




    /**
     * Matrix that converts handedness on the X-axis. Used to convert from LH to RH and vice versa.
     * @internal
     */
    export var ConvertHandednessMatrix: Matrix;
    /**
     * Checks if a node is a "noop" transform node, usually inserted by the glTF loader to correct handedness.
     * @internal
     */
    export function IsNoopNode(node: Node, useRightHandedSystem: boolean): boolean;


    export function GetFileExtensionFromMimeType(mimeType: BABYLON.GLTF2.ImageMimeType): string;
    /**
     * Gets cached image data from a texture's internal buffer, if available.
     * @param babylonTexture texture to check for cached image data
     * @returns image data and mime type if found; null otherwise
     */
    export function GetCachedImageAsync(babylonTexture: BaseTexture): Promise<Nullable<{
        data: ArrayBuffer;
        mimeType: string;
    }>>;


    /**
     * Class for generating STL data from a Babylon scene.
     */
    export class STLExport {
        /**
         * Exports the geometry of a Mesh array in .STL file format (ASCII)
         * @param meshes list defines the mesh to serialize
         * @param download triggers the automatic download of the file.
         * @param fileName changes the downloads fileName.
         * @param binary changes the STL to a binary type.
         * @param isLittleEndian toggle for binary type exporter.
         * @param doNotBakeTransform toggle if meshes transforms should be baked or not.
         * @param supportInstancedMeshes toggle to export instanced Meshes. Enabling support for instanced meshes will override doNoBakeTransform as true
         * @param exportIndividualMeshes toggle to export each mesh as an independent mesh. By default, all the meshes are combined into one mesh. This property has no effect when exporting in binary format
         * @returns the STL as UTF8 string
         */
        static CreateSTL(meshes: (Mesh | InstancedMesh)[], download?: boolean, fileName?: string, binary?: boolean, isLittleEndian?: boolean, doNotBakeTransform?: boolean, supportInstancedMeshes?: boolean, exportIndividualMeshes?: boolean): any;
    }


    /** Pure barrel — re-exports only side-effect-free modules */
















    /** Pure barrel — re-exports only side-effect-free modules */




    /** @internal */
    export var __IGLTFExporterExtension: number;
    /**
     * Interface for extending the exporter
     * @internal
     */
    export interface IGLTFExporterExtension {
        /**
         * The name of this extension
         */
        readonly name: string;
        /**
         * Defines whether this extension is enabled
         */
        enabled: boolean;
        /**
         * Defines whether this extension is required
         */
        required: boolean;
    }


    /** Pure barrel — re-exports only side-effect-free modules */




    export var DefaultTranslation: DeepImmutableObject<Vector3>;
    export var DefaultRotation: DeepImmutable<Quaternion>;
    export var DefaultScale: DeepImmutableObject<Vector3>;
    /**
     * Get the information necessary for enumerating a vertex buffer.
     * @param vertexBuffer the vertex buffer to enumerate
     * @param meshes the meshes that use the vertex buffer
     * @returns the information necessary to enumerate the vertex buffer
     */
    export function GetVertexBufferInfo(vertexBuffer: VertexBuffer, meshes: AbstractMesh[]): {
        byteOffset: number;
        byteStride: number;
        componentCount: number;
        type: number;
        count: number;
        normalized: boolean;
        totalVertices: number;
        kind: string;
    };
    export function GetAccessorElementCount(accessorType: BABYLON.GLTF2.AccessorType): number;
    export function FloatsNeed16BitInteger(floatArray: FloatArray): boolean;
    export function IsStandardVertexAttribute(type: string): boolean;
    export function GetAccessorType(kind: string, hasVertexColorAlpha: boolean): BABYLON.GLTF2.AccessorType;
    export function GetAttributeType(kind: string): string;
    export function GetPrimitiveMode(fillMode: number): BABYLON.GLTF2.MeshPrimitiveMode;
    export function IsTriangleFillMode(fillMode: number): boolean;
    export function NormalizeTangent(tangent: Vector4 | Vector3): void;
    export function ConvertToRightHandedPosition(value: Vector3): Vector3;
    /** @internal */
    export function ConvertToRightHandedTransformMatrix(matrix: Matrix): Matrix;
    /**
     * Converts, in-place, a left-handed quaternion to a right-handed quaternion via a change of basis.
     * @param value the unit quaternion to convert
     * @returns the converted quaternion
     */
    export function ConvertToRightHandedRotation(value: Quaternion): Quaternion;
    /**
     * Pre-multiplies a 180-degree Y rotation to the quaternion, in order to match glTF's flipped forward direction for cameras.
     * @param rotation Target camera rotation.
     */
    export function Rotate180Y(rotation: Quaternion): void;
    /**
     * Collapses GLTF parent and node into a single node, ignoring scaling.
     * This is useful for removing nodes that were added by the GLTF importer.
     * @param node Original GLTF node (Light or Camera).
     * @param parentNode Target parent node.
     */
    export function CollapseChildIntoParent(node: BABYLON.GLTF2.INode, parentNode: BABYLON.GLTF2.INode): void;
    /**
     * Checks whether a camera or light node is candidate for collapsing with its parent node.
     * This is useful for roundtrips, as the glTF Importer parents a new node to
     * lights and cameras to store their original transformation information.
     * @param babylonNode Babylon light or camera node.
     * @param parentBabylonNode Target Babylon parent node.
     * @returns True if the two nodes can be merged, false otherwise.
     */
    export function IsChildCollapsible(babylonNode: ShadowLight | TargetCamera | AreaLight, parentBabylonNode: Node): boolean;
    /**
     * Converts an IndicesArray into either a Uint32Array or Uint16Array.
     * If the `start` and `count` parameters specify a subset of the array, a new view is created.
     * If the input is a number[], the data is copied into a new buffer.
     * @param indices input array to be converted
     * @param start starting index
     * @param count number of indices
     * @param is32Bits whether the output should be Uint32Array (true) or Uint16Array (false) when indices is an `Array`
     * @returns a Uint32Array or Uint16Array
     * @internal
     */
    export function IndicesArrayToTypedSubarray(indices: IndicesArray, start: number, count: number, is32Bits: boolean): Uint32Array | Uint16Array;
    export function DataArrayToUint8Array(data: DataArray): Uint8Array;
    export function GetMinMax(data: DataArray, vertexBuffer: VertexBuffer, start: number, count: number): {
        min: number[];
        max: number[];
    };
    /**
     * Removes, in-place, object properties which have the same value as the default value.
     * Useful for avoiding unnecessary properties in the glTF JSON.
     * @param object the object to omit default values from
     * @param defaultValues a partial object with default values
     * @returns object with default values omitted
     */
    export function OmitDefaultValues<T extends object>(object: T, defaultValues: Partial<T>): T;


    /**
     * Indexed glTF root collections that KHR_interactivity references can target.
     */
    export type KhrInteractivityRootCollection = "nodes" | "animations" | "cameras" | "materials" | "meshes" | "textures" | "images" | "samplers" | "skins" | "scenes";
    /**
     * Mesh compression methods.
     */
    export type MeshCompressionMethod = "None" | "Draco";
    /**
     * Final entity remapping context exposed to a KHR_interactivity export provider.
     */
    export interface IKHRInteractivityExportContext {
        /**
         * Gets the final number of glTF nodes.
         * @returns final glTF node count
         */
        getNodeCount(): number;
        /**
         * Gets the final glTF node index for a Babylon node.
         * @param node Babylon node to resolve
         * @returns final glTF node index, or undefined when the node was not exported
         */
        getNodeIndex(node: Node): number | undefined;
        /**
         * Gets the final glTF animation index for a Babylon animation group.
         * @param animation Babylon animation group to resolve
         * @returns final glTF animation index, or undefined when the animation was not exported
         */
        getAnimationIndex(animation: AnimationGroup): number | undefined;
        /**
         * Gets the final glTF camera index for a Babylon camera.
         * @param camera Babylon camera to resolve
         * @returns final glTF camera index, or undefined when the camera was not exported
         */
        getCameraIndex(camera: Camera): number | undefined;
        /**
         * Gets the final glTF material index for a Babylon material.
         * @param material Babylon material to resolve
         * @returns final glTF material index, or undefined when the material was not exported
         */
        getMaterialIndex(material: Material): number | undefined;
        /**
         * Gets the final glTF index for an imported Babylon entity in a root collection.
         * @param collection target glTF root collection
         * @param entity imported Babylon entity associated with the source entry
         * @returns final glTF index, or undefined when the entity was not exported uniquely
         */
        getRootIndex?(collection: KhrInteractivityRootCollection, entity: object): number | undefined;
        /**
         * Writes a companion extension on an already-exported glTF node.
         * @param nodeIndex final glTF node index
         * @param extensionName companion extension name
         * @param value companion extension payload
         */
        setNodeExtension(nodeIndex: number, extensionName: string, value: unknown): void;
    }
    /**
     * Supplies a detached canonical KHR_interactivity document to the glTF serializer.
     */
    export interface IKHRInteractivityExportProvider {
        /** Whether KHR_interactivity must be listed in extensionsRequired. */
        readonly required: boolean;
        /** Additional operation or companion extensions referenced by the graph. */
        readonly additionalExtensionsUsed: readonly string[];
        /** Additional extensions that must be listed in extensionsRequired. */
        readonly additionalExtensionsRequired: readonly string[];
        /**
         * Builds the extension after final glTF entity indices are available.
         * @param context final serializer remapping context
         * @returns canonical KHR_interactivity extension payload
         */
        build(context: IKHRInteractivityExportContext): BABYLON.GLTF2.IKHRInteractivity;
    }
    /**
     * Holds a collection of exporter options and parameters
     */
    export interface IExportOptions {
        /**
         * Function which indicates whether a babylon node should be exported or not
         * @param node source Babylon node. It is used to check whether it should be exported to glTF or not
         * @returns boolean, which indicates whether the node should be exported (true) or not (false)
         */
        shouldExportNode?(node: Node): boolean;
        /**
         * Function which indicates whether an animation on the scene should be exported or not
         * @param animation source animation
         * @returns boolean, which indicates whether the animation should be exported (true) or not (false)
         */
        shouldExportAnimation?(animation: Animation): boolean;
        /**
         * Function to extract the part of the scene or node's `metadata` that will populate the corresponding
         * glTF object's `extras` field. If not defined, `node.metadata.gltf.extras` will be used.
         * @param metadata source metadata to read from
         * @returns the data to store into the glTF extras field
         */
        metadataSelector?(metadata: any): any;
        /**
         * The sample rate to bake animation curves. Defaults to 1 / 60.
         */
        animationSampleRate?: number;
        /**
         * Begin serialization without waiting for the scene to be ready. Defaults to false.
         */
        exportWithoutWaitingForScene?: boolean;
        /**
         * Indicates if unused vertex uv attributes should be included in export. Defaults to false.
         */
        exportUnusedUVs?: boolean;
        /**
         * Remove no-op root nodes when possible. Defaults to true. No-op roots are preserved when
         * {@link khrInteractivity} is provided because the graph may reference them.
         */
        removeNoopRootNodes?: boolean;
        /**
         * Indicates if coordinate system swapping root nodes should be included in export. Defaults to false.
         * @deprecated Please use removeNoopRootNodes instead
         */
        includeCoordinateSystemConversionNodes?: boolean;
        /**
         * Indicates what compression method to apply to mesh data.
         */
        meshCompressionMethod?: MeshCompressionMethod;
        /**
         * Canonical KHR_interactivity export provider. The provider is evaluated only after scene
         * nodes and animations have their final glTF indices.
         */
        khrInteractivity?: IKHRInteractivityExportProvider;
    }
    /**
     * Class for generating glTF data from a Babylon scene.
     */
    export class GLTF2Export {
        /**
         * Exports the scene to .gltf file format
         * @param scene Babylon scene
         * @param fileName Name to use for the .gltf file
         * @param options Exporter options
         * @returns Returns the exported data
         */
        static GLTFAsync(scene: Scene, fileName: string, options?: IExportOptions): Promise<GLTFData>;
        /**
         * Exports the scene to .glb file format
         * @param scene Babylon scene
         * @param fileName Name to use for the .glb file
         * @param options Exporter options
         * @returns Returns the exported data
         */
        static GLBAsync(scene: Scene, fileName: string, options?: IExportOptions): Promise<GLTFData>;
    }


    /**
     * Interface to store morph target information.
     * @internal
     */
    export interface IMorphTargetData {
        attributes: Record<string, number>;
        influence: number;
        name: string;
    }
    export function BuildMorphTargetBuffers(morphTarget: MorphTarget, mesh: AbstractMesh, bufferManager: BufferManager, bufferViews: BABYLON.GLTF2.IBufferView[], accessors: BABYLON.GLTF2.IAccessor[], convertToRightHanded: boolean): IMorphTargetData;


    /**
     * Computes the metallic factor from specular glossiness values.
     * @param diffuse diffused value
     * @param specular specular value
     * @param oneMinusSpecularStrength one minus the specular strength
     * @returns metallic value
     * @internal
     */
    export function _SolveMetallic(diffuse: number, specular: number, oneMinusSpecularStrength: number): number;
    /**
     * Computes the metallic/roughness factors from a Standard Material.
     * @internal
     */
    export function _ConvertToGLTFPBRMetallicRoughness(babylonStandardMaterial: StandardMaterial): BABYLON.GLTF2.IMaterialPbrMetallicRoughness;
    /**
     * Utility methods for working with glTF material conversion properties.
     * @internal
     */
    export class GLTFMaterialExporter {
        private readonly _exporter;
        private _textureMap;
        private _internalTextureToImage;
        constructor(_exporter: GLTFExporter);
        getTextureInfo(babylonTexture: Nullable<BaseTexture>): Nullable<BABYLON.GLTF2.ITextureInfo>;
        exportStandardMaterialAsync(babylonStandardMaterial: StandardMaterial, hasUVs: boolean): Promise<number>;
        private _finishMaterialAsync;
        /**
         * Resizes the two source textures to the same dimensions.  If a texture is null, a default white texture is generated.  If both textures are null, returns null
         * @param texture1 first texture to resize
         * @param texture2 second texture to resize
         * @param scene babylonjs scene
         * @returns resized textures or null
         */
        private _resizeTexturesToSameDimensions;
        /**
         * Convert Specular Glossiness Textures to Metallic Roughness
         * See link below for info on the material conversions from PBR Metallic/Roughness and Specular/Glossiness
         * @see https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Archived/KHR_materials_pbrSpecularGlossiness/examples/convert-between-workflows-bjs/js/babylon.pbrUtilities.js
         * @param diffuseTexture texture used to store diffuse information
         * @param specularGlossinessTexture texture used to store specular and glossiness information
         * @param factors specular glossiness material factors
         * @returns pbr metallic roughness interface or null
         */
        private _convertSpecularGlossinessTexturesToMetallicRoughnessAsync;
        /**
         * Converts specular glossiness material properties to metallic roughness
         * @param specularGlossiness interface with specular glossiness material properties
         * @returns interface with metallic roughness material properties
         */
        private _convertSpecularGlossinessToMetallicRoughness;
        /**
         * Calculates the surface reflectance, independent of lighting conditions
         * @param color Color source to calculate brightness from
         * @returns number representing the perceived brightness, or zero if color is undefined
         */
        private _getPerceivedBrightness;
        /**
         * Returns the maximum color component value
         * @param color
         * @returns maximum color component value, or zero if color is null or undefined
         */
        private _getMaxComponent;
        /**
         * Convert a PBRMaterial (Metallic/Roughness) to Metallic Roughness factors
         * @param baseColor Base color of the material
         * @param metallic Metallic factor of the material
         * @param roughness Roughness factor of the material
         * @param albedoTexture Albedo texture of the material
         * @param metallicTexture Metallic texture of the material
         * @param roughnessTexture Roughness texture of the material
         * @param babylonPBRMaterial BJS PBR Metallic Roughness Material
         * @param glTFPbrMetallicRoughness glTF PBR Metallic Roughness interface
         * @param hasUVs specifies if texture coordinates are present on the submesh to determine if textures should be applied
         * @returns glTF PBR Metallic Roughness factors
         */
        private _convertMetalRoughFactorsToMetallicRoughnessAsync;
        private _getTextureSampler;
        private _getGLTFTextureWrapMode;
        /**
         * Convert a PBRMaterial (Specular/Glossiness) to Metallic Roughness factors
         * @param babylonPBRMaterial BJS PBR Metallic Roughness Material
         * @param pbrMetallicRoughness glTF PBR Metallic Roughness interface
         * @param hasUVs specifies if texture coordinates are present on the submesh to determine if textures should be applied
         * @returns glTF PBR Metallic Roughness factors
         */
        private _convertSpecGlossFactorsToMetallicRoughnessAsync;
        exportPBRMaterialAsync(babylonPBRMaterial: PBRBaseMaterial, hasUVs: boolean): Promise<number>;
        private _setMetallicRoughnessPbrMaterialAsync;
        exportOpenPBRMaterialAsync(babylonOpenPBRMaterial: OpenPBRMaterial, hasUVs: boolean): Promise<number>;
        exportTextureAsync(babylonTexture: BaseTexture, overrideId?: Nullable<number>): Promise<Nullable<BABYLON.GLTF2.ITextureInfo>>;
        private _exportTextureImageAsync;
        private _exportImageAsync;
        private _exportTextureInfo;
        private _exportTextureSampler;
    }


    /** @internal */
    export var __IGLTFExporterExtensionV2: number;
    /**
     * Interface for a glTF exporter extension
     * @internal
     */
    export interface IGLTFExporterExtensionV2 extends IGLTFExporterExtension, IDisposable {
        /**
         * Define this method to get notified when a texture info is created
         * @param context The context when loading the asset
         * @param textureInfo The glTF texture info
         * @param babylonTexture The Babylon.js texture
         */
        postExportTexture?(context: string, textureInfo: BABYLON.GLTF2.ITextureInfo, babylonTexture: BaseTexture): void;
        /**
         * Define this method to get notified when a primitive is created
         * @param primitive glTF mesh primitive
         * @param bufferManager Buffer manager
         * @param accessors List of glTF accessors
         */
        postExportMeshPrimitive?(primitive: BABYLON.GLTF2.IMeshPrimitive, bufferManager: BufferManager, accessors: BABYLON.GLTF2.IAccessor[]): void;
        /**
         * Define this method to modify the default behavior when exporting a node
         * @param context The context when exporting the node
         * @param node glTF node
         * @param babylonNode BabylonJS node
         * @param nodeMap Current node mapping of babylon node to glTF node index. Useful for combining nodes together.
         * @param convertToRightHanded Flag indicating whether to convert values to right-handed
         * @param bufferManager Buffer manager
         * @returns nullable BABYLON.GLTF2.INode promise
         */
        postExportNodeAsync?(context: string, node: BABYLON.GLTF2.INode, babylonNode: Node, nodeMap: Map<Node, number>, convertToRightHanded: boolean, bufferManager: BufferManager): Promise<Nullable<BABYLON.GLTF2.INode>>;
        /**
         * Define this method to modify the default behavior when exporting a material
         * @param context The context when exporting the material
         * @param node glTF material
         * @param babylonMaterial BabylonJS material
         * @returns nullable BABYLON.GLTF2.IMaterial promise
         */
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
        /**
         * Define this method to return additional textures to export from a material
         * @param context The context when exporting the material
         * @param node glTF material
         * @param babylonMaterial BabylonJS material
         * @returns List of textures
         */
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        /**
         * Define this method to modify the glTF buffer data before it is finalized and written
         * @param bufferManager Buffer manager
         */
        preGenerateBinaryAsync?(bufferManager: BufferManager): Promise<void>;
        /** Gets a boolean indicating that this extension was used */
        wasUsed: boolean;
        /** Gets a boolean indicating that this extension is required for the file to work */
        required: boolean;
        /**
         * Called after the exporter state changes to EXPORTING
         */
        onExporting?(): void;
    }


    /** @internal */
    export class GLTFExporter {
        readonly _glTF: BABYLON.GLTF2.IGLTF;
        readonly _animations: BABYLON.GLTF2.IAnimation[];
        readonly _accessors: BABYLON.GLTF2.IAccessor[];
        readonly _bufferViews: BABYLON.GLTF2.IBufferView[];
        readonly _cameras: BABYLON.GLTF2.ICamera[];
        readonly _images: BABYLON.GLTF2.IImage[];
        readonly _materials: BABYLON.GLTF2.IMaterial[];
        readonly _meshes: BABYLON.GLTF2.IMesh[];
        readonly _nodes: BABYLON.GLTF2.INode[];
        readonly _samplers: BABYLON.GLTF2.ISampler[];
        readonly _scenes: BABYLON.GLTF2.IScene[];
        readonly _skins: BABYLON.GLTF2.ISkin[];
        readonly _textures: BABYLON.GLTF2.ITexture[];
        readonly _babylonScene: Scene;
        readonly _imageData: {
            [fileName: string]: Blob;
        };
        /**
         * Baked animation sample rate
         */
        private _animationSampleRate;
        private readonly _options;
        _shouldUseGlb: boolean;
        readonly _materialExporter: GLTFMaterialExporter;
        private readonly _extensions;
        readonly _bufferManager: BufferManager;
        private readonly _shouldExportNodeMap;
        private readonly _nodeMap;
        private readonly _animationGroupMap;
        readonly _materialMap: Map<Material, number>;
        private readonly _camerasMap;
        private readonly _nodesCameraMap;
        private readonly _skinMap;
        private readonly _nodesSkinMap;
        readonly _materialNeedsUVsSet: Set<Material>;
        private static readonly _ExtensionNames;
        private static readonly _ExtensionFactories;
        private static readonly _ExtensionOrders;
        private _ApplyExtension;
        private _ApplyExtensions;
        _extensionsPostExportNodeAsync(context: string, node: BABYLON.GLTF2.INode, babylonNode: Node, nodeMap: Map<Node, number>, convertToRightHanded: boolean): Promise<Nullable<BABYLON.GLTF2.INode>>;
        _extensionsPostExportMaterialAsync(context: string, material: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<Nullable<BABYLON.GLTF2.IMaterial>>;
        /**
         * Get additional textures for a material
         * @param context The context when loading the asset
         * @param material The glTF material
         * @param babylonMaterial The Babylon.js material
         * @returns List of additional textures
         */
        _extensionsPostExportMaterialAdditionalTexturesAsync(context: string, material: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        _extensionsPostExportTextures(context: string, textureInfo: BABYLON.GLTF2.ITextureInfo, babylonTexture: BaseTexture): void;
        _extensionsPostExportMeshPrimitive(primitive: BABYLON.GLTF2.IMeshPrimitive): void;
        _extensionsPreGenerateBinaryAsync(): Promise<void>;
        private _forEachExtensions;
        private _extensionsOnExporting;
        private _loadExtensions;
        constructor(babylonScene?: Nullable<Scene>, options?: IExportOptions);
        dispose(): void;
        get options(): Required<Omit<IExportOptions, "khrInteractivity">> & Pick<IExportOptions, "khrInteractivity">;
        static RegisterExtension(name: string, factory: (exporter: GLTFExporter) => IGLTFExporterExtensionV2, order?: number): void;
        static UnregisterExtension(name: string): boolean;
        private _generateJSON;
        generateGLTFAsync(glTFPrefix: string): Promise<GLTFData>;
        private _generateBinaryAsync;
        /**
         * Pads the number to a multiple of 4
         * @param num number to pad
         * @returns padded number
         */
        private _getPadding;
        generateGLBAsync(glTFPrefix: string): Promise<GLTFData>;
        private _setNodeTransformation;
        private _setCameraTransformation;
        private _listAvailableCameras;
        private _exportAndAssignCameras;
        private _listAvailableSkeletons;
        private _exportAndAssignSkeletons;
        private _exportSceneAsync;
        /** @internal */
        _getNodeIndex(node: Node): number | undefined;
        /** @internal */
        _getAnimationIndex(animationGroup: AnimationGroup): number | undefined;
        /** @internal */
        _getCameraIndex(camera: Camera): number | undefined;
        /** @internal */
        _getMaterialIndex(material: Material): number | undefined;
        /** @internal */
        _getRootIndex(collection: KhrInteractivityRootCollection, entity: object): number | undefined;
        /** @internal */
        _setNodeExtension(nodeIndex: number, extensionName: string, value: unknown): void;
        private _shouldExportNode;
        private _exportNodesAsync;
        private _collectBuffers;
        private _exportBuffers;
        /**
         * Processes a node to be exported to the glTF file
         * @returns A promise that resolves once the node has been exported
         * @internal
         */
        private _exportNodeAsync;
        /**
         * Creates a glTF node from a Babylon.js node. If skipped, returns null.
         * @internal
         */
        private _createNodeAsync;
        private _exportIndices;
        private _exportVertexBuffer;
        private _exportMaterialAsync;
        private _exportMeshAsync;
    }


    /**
     * Class for holding and downloading glTF file data
     */
    export class GLTFData {
        /**
         * Object which contains the file name as the key and its data as the value
         */
        readonly files: {
            [fileName: string]: string | Blob;
        };
        /**
         * @deprecated Use files instead
         */
        get glTFFiles(): {
            [fileName: string]: string | Blob;
        };
        /**
         * Downloads the glTF data as files based on their names and data
         */
        downloadFiles(): void;
    }


    /**
     * @internal
     * Interface to store animation data.
     */
    export interface _IAnimationData {
        /**
         * Keyframe data.
         */
        inputs: number[];
        /**
         * Value data.
         */
        outputs: number[][];
        /**
         * Animation interpolation data.
         */
        samplerInterpolation: BABYLON.GLTF2.AnimationSamplerInterpolation;
        /**
         * Minimum keyframe value.
         */
        inputsMin: number;
        /**
         * Maximum keyframe value.
         */
        inputsMax: number;
    }
    /**
     * @internal
     */
    export interface _IAnimationInfo {
        /**
         * The target channel for the animation
         */
        animationChannelTargetPath: BABYLON.GLTF2.AnimationChannelTargetPath;
        /**
         * The glTF accessor type for the data.
         */
        dataAccessorType: BABYLON.GLTF2.AccessorType.VEC3 | BABYLON.GLTF2.AccessorType.VEC4 | BABYLON.GLTF2.AccessorType.SCALAR;
        /**
         * Specifies if quaternions should be used.
         */
        useQuaternion: boolean;
    }
    /**
     * @internal
     * Utility class for generating glTF animation data from BabylonJS.
     */
    export class _GLTFAnimation {
        /**
         * Determine if a node is transformable - ie has properties it should be part of animation of transformation.
         * @param babylonNode the node to test
         * @returns true if can be animated, false otherwise. False if the parameter is null or undefined.
         */
        private static _IsTransformable;
        /**
         * @ignore
         *
         * Creates glTF channel animation from BabylonJS animation.
         * @param babylonTransformNode - BabylonJS mesh.
         * @param animation - animation.
         * @param animationChannelTargetPath - The target animation channel.
         * @param useQuaternion - Specifies if quaternions are used.
         * @returns nullable IAnimationData
         */
        static _CreateNodeAnimation(babylonTransformNode: Node, animation: Animation, animationChannelTargetPath: BABYLON.GLTF2.AnimationChannelTargetPath, useQuaternion: boolean, animationSampleRate: number): Nullable<_IAnimationData>;
        private static _DeduceAnimationInfo;
        /**
         * @ignore
         * Create node animations from the transform node animations
         * @param babylonNode
         * @param runtimeGLTFAnimation
         * @param idleGLTFAnimations
         * @param nodeMap
         * @param nodes
         * @param bufferManager
         * @param bufferViews
         * @param accessors
         * @param animationSampleRate
         * @param useRightHanded
         * @param shouldExportAnimation
         */
        static _CreateNodeAnimationFromNodeAnimations(babylonNode: Node, runtimeGLTFAnimation: BABYLON.GLTF2.IAnimation, idleGLTFAnimations: BABYLON.GLTF2.IAnimation[], nodeMap: Map<Node, number>, nodes: BABYLON.GLTF2.INode[], bufferManager: BufferManager, bufferViews: BABYLON.GLTF2.IBufferView[], accessors: BABYLON.GLTF2.IAccessor[], animationSampleRate: number, useRightHanded: boolean, shouldExportAnimation?: (animation: Animation) => boolean): void;
        /**
         * @ignore
         * Create individual morph animations from the mesh's morph target animation tracks
         * @param babylonNode
         * @param runtimeGLTFAnimation
         * @param idleGLTFAnimations
         * @param nodeMap
         * @param nodes
         * @param bufferManager
         * @param bufferViews
         * @param accessors
         * @param animationSampleRate
         * @param useRightHanded
         * @param shouldExportAnimation
         */
        static _CreateMorphTargetAnimationFromMorphTargetAnimations(babylonNode: Node, runtimeGLTFAnimation: BABYLON.GLTF2.IAnimation, idleGLTFAnimations: BABYLON.GLTF2.IAnimation[], nodeMap: Map<Node, number>, nodes: BABYLON.GLTF2.INode[], bufferManager: BufferManager, bufferViews: BABYLON.GLTF2.IBufferView[], accessors: BABYLON.GLTF2.IAccessor[], animationSampleRate: number, useRightHanded: boolean, shouldExportAnimation?: (animation: Animation) => boolean): void;
        /**
         * @internal
         * Create node and morph animations from the animation groups
         * @param babylonScene
         * @param glTFAnimations
         * @param nodeMap
         * @param nodes
         * @param bufferManager
         * @param bufferViews
         * @param accessors
         * @param animationSampleRate
         * @param leftHandedNodes nodes that require right-handed conversion
         * @param shouldExportAnimation optional animation filter
         * @param animationGroupMap final glTF animation index for each exported Babylon animation group
         */
        static _CreateNodeAndMorphAnimationFromAnimationGroups(babylonScene: Scene, glTFAnimations: BABYLON.GLTF2.IAnimation[], nodeMap: Map<Node, number>, bufferManager: BufferManager, bufferViews: BABYLON.GLTF2.IBufferView[], accessors: BABYLON.GLTF2.IAccessor[], animationSampleRate: number, leftHandedNodes: Set<Node>, shouldExportAnimation?: (animation: Animation) => boolean, animationGroupMap?: Map<AnimationGroup, number>): void;
        private static _AddAnimation;
        /**
         * Create a baked animation
         * @param babylonTransformNode BabylonJS mesh
         * @param animation BabylonJS animation corresponding to the BabylonJS mesh
         * @param animationChannelTargetPath animation target channel
         * @param minFrame minimum animation frame
         * @param maxFrame maximum animation frame
         * @param fps frames per second of the animation
         * @param sampleRate
         * @param inputs input key frames of the animation
         * @param outputs output key frame data of the animation
         * @param minMaxFrames
         * @param minMaxFrames.min
         * @param minMaxFrames.max
         * @param useQuaternion specifies if quaternions should be used
         */
        private static _CreateBakedAnimation;
        private static _ConvertFactorToVector3OrQuaternion;
        private static _SetInterpolatedValue;
        /**
         * Creates linear animation from the animation key frames
         * @param babylonTransformNode BabylonJS mesh
         * @param animation BabylonJS animation
         * @param animationChannelTargetPath The target animation channel
         * @param inputs Array to store the key frame times
         * @param outputs Array to store the key frame data
         * @param useQuaternion Specifies if quaternions are used in the animation
         */
        private static _CreateLinearOrStepAnimation;
        /**
         * Creates cubic spline animation from the animation key frames
         * @param babylonTransformNode BabylonJS mesh
         * @param animation BabylonJS animation
         * @param animationChannelTargetPath The target animation channel
         * @param inputs Array to store the key frame times
         * @param outputs Array to store the key frame data
         * @param useQuaternion Specifies if quaternions are used in the animation
         */
        private static _CreateCubicSplineAnimation;
        private static _GetBasePositionRotationOrScale;
        /**
         * Adds a key frame value
         * @param keyFrame
         * @param animation
         * @param outputs
         * @param animationChannelTargetPath
         * @param babylonTransformNode
         * @param useQuaternion
         */
        private static _AddKeyframeValue;
        /**
         * @internal
         * Determine the interpolation based on the key frames
         * @param keyFrames
         * @param animationChannelTargetPath
         * @param useQuaternion
         */
        private static _DeduceInterpolation;
        /**
         * Adds an input tangent or output tangent to the output data
         * If an input tangent or output tangent is missing, it uses the zero vector or zero quaternion
         * @param tangentType Specifies which type of tangent to handle (inTangent or outTangent)
         * @param outputs The animation data by keyframe
         * @param animationChannelTargetPath The target animation channel
         * @param interpolation The interpolation type
         * @param keyFrame The key frame with the animation data
         * @param useQuaternion Specifies if quaternions are used
         */
        private static _AddSplineTangent;
        /**
         * Get the minimum and maximum key frames' frame values
         * @param keyFrames animation key frames
         * @returns the minimum and maximum key frame value
         */
        private static _CalculateMinMaxKeyFrames;
    }


    /** @internal */
    export class DataWriter {
        private _data;
        private _dataView;
        private _byteOffset;
        writeTypedArray(value: Exclude<TypedArray, BigInt64Array | BigUint64Array>): void;
        constructor(byteLength: number);
        get byteOffset(): number;
        getOutputData(): Uint8Array<ArrayBuffer>;
        writeUInt8(value: number): void;
        writeInt8(value: number): void;
        writeInt16(entry: number): void;
        writeUInt16(value: number): void;
        writeInt32(entry: number): void;
        writeUInt32(value: number): void;
        writeFloat32(value: number): void;
        writeFloat64(value: number): void;
        private _checkGrowBuffer;
    }


    type TypedArrayForglTF = Exclude<TypedArray, Float64Array | BigInt64Array | BigUint64Array>;
    interface IPropertyWithBufferView {
        bufferView?: number;
    }
    /**
     * Utility class to centralize the management of binary data, bufferViews, and the objects that reference them.
     * @internal
     */
    export class BufferManager {
        /**
         * Maps a bufferView to its data
         */
        private _bufferViewToData;
        /**
         * Maps a bufferView to glTF objects that reference it via a "bufferView" property (e.g. accessors, images)
         */
        private _bufferViewToProperties;
        /**
         * Maps an accessor to its bufferView
         */
        private _accessorToBufferView;
        /**
         * Generates a binary buffer from the stored bufferViews. Also populates the bufferViews list.
         * @param bufferViews The list of bufferViews to be populated while writing the binary
         * @returns The binary buffer
         */
        generateBinary(bufferViews: BABYLON.GLTF2.IBufferView[]): Uint8Array<ArrayBuffer>;
        /**
         * Creates a buffer view based on the supplied arguments
         * @param data a TypedArray to create the bufferView for
         * @param byteStride byte distance between consecutive elements
         * @returns bufferView for glTF
         */
        createBufferView(data: TypedArrayForglTF, byteStride?: number): BABYLON.GLTF2.IBufferView;
        /**
         * Creates an accessor based on the supplied arguments and assigns it to the bufferView
         * @param bufferView The glTF bufferView referenced by this accessor
         * @param type The type of the accessor
         * @param componentType The datatype of components in the attribute
         * @param count The number of attributes referenced by this accessor
         * @param byteOffset The offset relative to the start of the bufferView in bytes
         * @param minMax Minimum and maximum value of each component in this attribute
         * @param normalized Specifies whether integer data values are normalized before usage
         * @returns accessor for glTF
         */
        createAccessor(bufferView: BABYLON.GLTF2.IBufferView, type: BABYLON.GLTF2.AccessorType, componentType: BABYLON.GLTF2.AccessorComponentType, count: number, byteOffset?: number, minMax?: {
            min: number[];
            max: number[];
        }, normalized?: boolean): BABYLON.GLTF2.IAccessor;
        /**
         * Assigns a bufferView to a glTF object that references it
         * @param object The glTF object
         * @param bufferView The bufferView to assign
         */
        setBufferView(object: IPropertyWithBufferView, bufferView: BABYLON.GLTF2.IBufferView): void;
        /**
         * Removes buffer view from the binary data, as well as from all its known references
         * @param bufferView the bufferView to remove
         */
        removeBufferView(bufferView: BABYLON.GLTF2.IBufferView): void;
        getBufferView(accessor: BABYLON.GLTF2.IAccessor): BABYLON.GLTF2.IBufferView;
        getPropertiesWithBufferView(bufferView: BABYLON.GLTF2.IBufferView): IPropertyWithBufferView[];
        getData(bufferView: BABYLON.GLTF2.IBufferView): TypedArrayForglTF;
        private _verifyBufferView;
    }


    /** Pure barrel — re-exports only side-effect-free modules */




    /**
     * @internal
     */
    export class KHR_texture_transform implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_texture_transform";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        /** Reference to the glTF exporter */
        private _wasUsed;
        constructor();
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        postExportTexture?(context: string, textureInfo: BABYLON.GLTF2.ITextureInfo, babylonTexture: Texture): void;
    }
    /**
     * Registers the KHR_texture_transform glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_texture_transform(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_texture_transform.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_texture_basisu/README.md)
     */
    export class KHR_texture_basisu implements IGLTFExporterExtensionV2 {
        readonly name = "KHR_texture_basisu";
        enabled: boolean;
        required: boolean;
        private _wasUsed;
        get wasUsed(): boolean;
        private _exporter;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /**
         * Called after a texture is exported to register the encoded image MIME type.
         * @param _ - the name of the exported babylon texture (unused)
         * @param textureInfo - the glTF texture info for the exported texture
         */
        postExportTexture(_: string, textureInfo: BABYLON.GLTF2.ITextureInfo): void;
    }
    /**
     * Registers the KHR_texture_basisu glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_texture_basisu(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_texture_basisu.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * TODO: In-progress specification
     * [Specification](https://github.com/KhronosGroup/glTF/blob/7ea427ed55d44427e83c0a6d1c87068b1a4151c5/extensions/2.0/Khronos/KHR_materials_volume_scatter/README.md)
     */
    export class KHR_materials_volume_scatter implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_volume_scatter";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _exporter;
        private _wasUsed;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /**
         * After exporting a material, deal with additional textures
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns array of additional textures to export
         */
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        private _isExtensionEnabled;
        /**
         * After exporting a material
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns promise that resolves with the updated node
         */
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_volume_scatter glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_volume_scatter(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_volume_scatter.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_materials_volume/README.md)
     */
    export class KHR_materials_volume implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_volume";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _exporter;
        private _wasUsed;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /**
         * After exporting a material, deal with additional textures
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns array of additional textures to export
         */
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        private _isExtensionEnabled;
        private _hasTexturesExtension;
        /**
         * After exporting a material
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns promise that resolves with the updated node
         */
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_volume glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_volume(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_volume.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * @internal
     */
    export class KHR_materials_unlit implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_unlit";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _wasUsed;
        constructor();
        /** @internal */
        get wasUsed(): boolean;
        dispose(): void;
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_unlit glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_unlit(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_unlit.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_materials_transmission/README.md)
     */
    export class KHR_materials_transmission implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_transmission";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _exporter;
        private _wasUsed;
        constructor(exporter: GLTFExporter);
        /** Dispose */
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /**
         * After exporting a material, deal with additional textures
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns array of additional textures to export
         */
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        private _isExtensionEnabled;
        /**
         * After exporting a material
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns true if successful
         */
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_transmission glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_transmission(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_transmission.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_materials_specular/README.md)
     */
    export class KHR_materials_specular implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_specular";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _exporter;
        private _wasUsed;
        constructor(exporter: GLTFExporter);
        /** Dispose */
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /**
         * After exporting a material, deal with the additional textures
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns array of additional textures to export
         */
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        private _isExtensionEnabled;
        private _hasTexturesExtension;
        /**
         * After exporting a material
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns promise, resolves with the material
         */
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_specular glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_specular(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_specular.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * @internal
     */
    export class KHR_materials_sheen implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_sheen";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _wasUsed;
        private _exporter;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        postExportMaterialAdditionalTexturesAsync(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        postExportMaterialAsync(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_sheen glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_sheen(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_sheen.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * TODO: Add link to specification. Specification still being drafted.
     * @experimental
     */
    export class KHR_materials_openpbr implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_openpbr";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _wasUsed;
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /**
         * After exporting a material
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns promise that resolves with the updated node
         */
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_openpbr glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_openpbr(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_openpbr.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * @internal
     */
    export class KHR_materials_iridescence implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_iridescence";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _exporter;
        private _wasUsed;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_iridescence glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_iridescence(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_iridescence.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_materials_ior/README.md)
     */
    export class KHR_materials_ior implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_ior";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _wasUsed;
        constructor();
        /** Dispose */
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        private _isExtensionEnabled;
        /**
         * After exporting a material
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns promise, resolves with the material
         */
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_ior glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_ior(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_ior.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * @internal
     */
    export class KHR_materials_fuzz implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_fuzz";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _wasUsed;
        private _exporter;
        constructor(exporter: GLTFExporter);
        /**
         * Cache that holds temporary merged textures created during export
         */
        private _mergedTexturesMap;
        /**
         * Cache that holds internal textures of merged textures created during export
         */
        private _cachedInternalTexturesMap;
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        postExportMaterialAdditionalTexturesAsync(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        postExportMaterialAsync(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_fuzz glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_fuzz(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_fuzz.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_materials_emissive_strength/README.md)
     */
    export class KHR_materials_emissive_strength implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_emissive_strength";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _wasUsed;
        /** Dispose */
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /**
         * After exporting a material
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns promise, resolves with the material
         */
        postExportMaterialAsync(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_emissive_strength glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_emissive_strength(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_emissive_strength.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/87bd64a7f5e23c84b6aef2e6082069583ed0ddb4/extensions/2.0/Khronos/KHR_materials_dispersion/README.md)
     * @experimental
     */
    export class KHR_materials_dispersion implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_dispersion";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _wasUsed;
        /** Constructor */
        constructor();
        /** Dispose */
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        private _isExtensionEnabled;
        /**
         * After exporting a material
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns promise, resolves with the material
         */
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_dispersion glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_dispersion(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_dispersion.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Proposed Specification](https://github.com/KhronosGroup/glTF/pull/1825)
     * !!! Experimental Extension Subject to Changes !!!
     */
    export class KHR_materials_diffuse_transmission implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_diffuse_transmission";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _exporter;
        private _wasUsed;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /**
         * After exporting a material, deal with additional textures
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns array of additional textures to export
         */
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        private _isExtensionEnabled;
        /**
         * After exporting a material
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns promise that resolves with the updated node
         */
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_diffuse_transmission glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_diffuse_transmission(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_diffuse_transmission.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * @internal
     */
    export class KHR_materials_diffuse_roughness implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_diffuse_roughness";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _exporter;
        private _wasUsed;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_diffuse_roughness glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_diffuse_roughness(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_diffuse_roughness.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * @internal
     */
    export class KHR_materials_coat implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_coat";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _exporter;
        private _wasUsed;
        constructor(exporter: GLTFExporter);
        /**
         * Cache that holds temporary merged textures created during export
         */
        private _mergedTexturesMap;
        /**
         * Cache that holds internal textures of merged textures created during export
         */
        private _cachedInternalTexturesMap;
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_coat glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_coat(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_coat.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * @internal
     */
    export class KHR_materials_clearcoat implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_clearcoat";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _exporter;
        private _wasUsed;
        constructor(exporter: GLTFExporter);
        /**
         * Cache that holds temporary merged textures created during export
         */
        private _mergedTexturesMap;
        /**
         * Cache that holds internal textures of merged textures created during export
         */
        private _cachedInternalTexturesMap;
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_clearcoat glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_clearcoat(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_clearcoat.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * @internal
     */
    export class KHR_materials_anisotropy implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_materials_anisotropy";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        private _exporter;
        private _wasUsed;
        private _anisoTexturesMap;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /**
         * After exporting a material, deal with the additional textures
         * @param context GLTF context of the material
         * @param node exported GLTF node
         * @param babylonMaterial corresponding babylon material
         * @returns array of additional textures to export
         */
        postExportMaterialAdditionalTexturesAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BaseTexture[]>;
        postExportMaterialAsync?(context: string, node: BABYLON.GLTF2.IMaterial, babylonMaterial: Material): Promise<BABYLON.GLTF2.IMaterial>;
    }
    /**
     * Registers the KHR_materials_anisotropy glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_materials_anisotropy(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_materials_anisotropy.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/master/extensions/2.0/Khronos/KHR_lights_punctual/README.md)
     */
    export class KHR_lights_punctual implements IGLTFExporterExtensionV2 {
        /** The name of this extension. */
        readonly name = "KHR_lights_punctual";
        /** Defines whether this extension is enabled. */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        /** Reference to the glTF exporter */
        private _exporter;
        private _lights;
        /**
         * @internal
         */
        constructor(exporter: GLTFExporter);
        /** @internal */
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /** @internal */
        onExporting(): void;
        /**
         * Define this method to modify the default behavior when exporting a node
         * @param context The context when exporting the node
         * @param node glTF node
         * @param babylonNode BabylonJS node
         * @param nodeMap Node mapping of babylon node to glTF node index
         * @param convertToRightHanded Flag to convert the values to right-handed
         * @returns nullable BABYLON.GLTF2.INode promise
         */
        postExportNodeAsync(context: string, node: BABYLON.GLTF2.INode, babylonNode: Node, nodeMap: Map<Node, number>, convertToRightHanded: boolean): Promise<Nullable<BABYLON.GLTF2.INode>>;
    }
    /**
     * Registers the KHR_lights_punctual glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_lights_punctual(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_lights_punctual.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Khronos/KHR_interactivity)
     */
    export class KHR_interactivity implements IGLTFExporterExtensionV2 {
        private _exporter;
        /** The extension name. */
        readonly name = "KHR_interactivity";
        /** Whether this extension is enabled for the current export. */
        readonly enabled: boolean;
        /** Whether this extension is required for the exported asset. */
        readonly required: boolean;
        /**
         * @param _exporter owning glTF exporter
         */
        constructor(_exporter: GLTFExporter);
        /** @internal */
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /** @internal */
        onExporting(): void;
    }
    /**
     * Registers the KHR_interactivity glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_interactivity(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_interactivity.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Khronos/KHR_draco_mesh_compression/README.md)
     */
    export class KHR_draco_mesh_compression implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "KHR_draco_mesh_compression";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** KHR_draco_mesh_compression is required, as uncompressed fallback data is not yet implemented. */
        required: boolean;
        /** BufferViews used for Draco data, which may be eligible for removal after Draco encoding */
        private _bufferViewsUsed;
        /** Accessors that were replaced with Draco data, which may be eligible for removal after Draco encoding */
        private _accessorsUsed;
        /** Promise pool for Draco encoding work */
        private _encodePromises;
        private _wasUsed;
        /** @internal */
        get wasUsed(): boolean;
        /** @internal */
        constructor(exporter: GLTFExporter);
        /** @internal */
        dispose(): void;
        /** @internal */
        postExportMeshPrimitive(primitive: BABYLON.GLTF2.IMeshPrimitive, bufferManager: BufferManager, accessors: BABYLON.GLTF2.IAccessor[]): void;
        /** @internal */
        preGenerateBinaryAsync(bufferManager: BufferManager): Promise<void>;
    }
    /**
     * Registers the KHR_draco_mesh_compression glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterKHR_draco_mesh_compression(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./KHR_draco_mesh_compression.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Vendor/EXT_texture_webp/README.md)
     */
    export class EXT_texture_webp implements IGLTFExporterExtensionV2 {
        readonly name = "EXT_texture_webp";
        enabled: boolean;
        required: boolean;
        private _wasUsed;
        get wasUsed(): boolean;
        private _exporter;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /**
         * Called after a texture is exported to register the encoded image MIME type.
         * @param _ - the name of the exported babylon texture (unused)
         * @param textureInfo - the glTF texture info for the exported texture
         */
        postExportTexture(_: string, textureInfo: BABYLON.GLTF2.ITextureInfo): void;
    }
    /**
     * Registers the EXT_texture_webp glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterEXT_texture_webp(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./EXT_texture_webp.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Proposed Specification](https://github.com/KhronosGroup/glTF/blob/5cb7518cf9a1bfb8268320026961b21caf5a4aac/extensions/2.0/Vendor/EXT_texture_avif/README.md)
     * @experimental
     */
    export class EXT_texture_avif implements IGLTFExporterExtensionV2 {
        readonly name = "EXT_texture_avif";
        enabled: boolean;
        required: boolean;
        private _wasUsed;
        get wasUsed(): boolean;
        private _exporter;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /**
         * Called after a texture is exported to register the encoded image MIME type.
         * @param _ - the name of the exported babylon texture (unused)
         * @param textureInfo - the glTF texture info for the exported texture
         */
        postExportTexture(_: string, textureInfo: BABYLON.GLTF2.ITextureInfo): void;
    }
    /**
     * Registers the EXT_texture_avif glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterEXT_texture_avif(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./EXT_texture_avif.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/main/extensions/2.0/Vendor/EXT_mesh_gpu_instancing/README.md)
     */
    export class EXT_mesh_gpu_instancing implements IGLTFExporterExtensionV2 {
        /** Name of this extension */
        readonly name = "EXT_mesh_gpu_instancing";
        /** Defines whether this extension is enabled */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        /**
         * Internal state to emit warning about instance color alpha once
         */
        private _instanceColorWarned;
        private _exporter;
        private _wasUsed;
        constructor(exporter: GLTFExporter);
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /**
         * After node is exported
         * @param context the GLTF context when loading the asset
         * @param node the node exported
         * @param babylonNode the corresponding babylon node
         * @param nodeMap map from babylon node id to node index
         * @param convertToRightHanded true if we need to convert data from left hand to right hand system.
         * @param bufferManager buffer manager
         * @returns nullable promise, resolves with the node
         */
        postExportNodeAsync(context: string, node: Nullable<BABYLON.GLTF2.INode>, babylonNode: Node, nodeMap: Map<Node, number>, convertToRightHanded: boolean, bufferManager: BufferManager): Promise<Nullable<BABYLON.GLTF2.INode>>;
        private _buildAccessor;
    }
    /**
     * Registers the EXT_mesh_gpu_instancing glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterEXT_mesh_gpu_instancing(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./EXT_mesh_gpu_instancing.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * [Specification](https://github.com/KhronosGroup/glTF/blob/master/extensions/2.0/Khronos/EXT_lights_area/README.md)
     */
    export class EXT_lights_area implements IGLTFExporterExtensionV2 {
        /** The name of this extension. */
        readonly name = "EXT_lights_area";
        /** Defines whether this extension is enabled. */
        enabled: boolean;
        /** Defines whether this extension is required */
        required: boolean;
        /** Reference to the glTF exporter */
        private _exporter;
        private _lights;
        /**
         * @internal
         */
        constructor(exporter: GLTFExporter);
        /** @internal */
        dispose(): void;
        /** @internal */
        get wasUsed(): boolean;
        /** @internal */
        onExporting(): void;
        /**
         * Define this method to modify the default behavior when exporting a node
         * @param context The context when exporting the node
         * @param node glTF node
         * @param babylonNode BabylonJS node
         * @param nodeMap Node mapping of babylon node to glTF node index
         * @param convertToRightHanded Flag to convert the values to right-handed
         * @returns nullable BABYLON.GLTF2.INode promise
         */
        postExportNodeAsync(context: string, node: BABYLON.GLTF2.INode, babylonNode: Node, nodeMap: Map<Node, number>, convertToRightHanded: boolean): Promise<Nullable<BABYLON.GLTF2.INode>>;
    }
    /**
     * Registers the EXT_lights_area glTF serializer extension with the {@link GLTFExporter}.
     * Safe to call multiple times; only the first call has an effect.
     */
    export function RegisterEXT_lights_area(): void;


    /**
     * Re-exports the pure implementation and applies the runtime registration side effect.
     * Import "./EXT_lights_area.pure" for tree-shakeable, side-effect-free usage.
     */


    /**
     * Options for the USDZ export
     */
    export interface IUSDZExportOptions {
        /**
         * URL to load the fflate library from
         */
        fflateUrl?: string;
        /**
         * Include anchoring properties in the USDZ file
         */
        includeAnchoringProperties?: boolean;
        /**
         * Anchoring type (plane by default)
         */
        anchoringType?: string;
        /**
         * Plane anchoring alignment (horizontal by default)
         */
        planeAnchoringAlignment?: string;
        /**
         * Model file name (model.usda by default)
         */
        modelFileName?: string;
        /**
         * Precision to use for number (5 by default)
         */
        precision?: number;
        /**
         * Export the camera (false by default)
         */
        exportCamera?: boolean;
        /**
         * Camera sensor width (35 by default)
         */
        cameraSensorWidth?: number;
    }
    /**
     *
     * @param scene scene to export
     * @param options options to configure the export
     * @param meshPredicate predicate to filter the meshes to export
     * @returns a uint8 array containing the USDZ file
     * @see [Simple sphere](https://playground.babylonjs.com/#H2G5XW#6)
     * @see [Red sphere](https://playground.babylonjs.com/#H2G5XW#7)
     * @see [Boombox](https://playground.babylonjs.com/#5N3RWK#5)
     */
    export function USDZExportAsync(scene: Scene, options: Partial<IUSDZExportOptions>, meshPredicate?: (m: Mesh) => boolean): Promise<Uint8Array>;


    /** Pure barrel — re-exports only side-effect-free modules */




    /** Pure barrel — re-exports only side-effect-free modules */


    /**
     * Class for generating OBJ data from a Babylon scene.
     */
    export class OBJExport {
        /**
         * Exports the geometry of a Mesh array in .OBJ file format (text)
         * @param meshes defines the list of meshes to serialize
         * @param materials defines if materials should be exported
         * @param matlibname defines the name of the associated mtl file
         * @param globalposition defines if the exported positions are globals or local to the exported mesh
         * @returns the OBJ content
         */
        static OBJ(meshes: Mesh[], materials?: boolean, matlibname?: string, globalposition?: boolean): string;
        /**
         * Exports the material(s) of a mesh in .MTL file format (text)
         * @param mesh defines the mesh to extract the material from
         * @param materialName defines the name of the material in the output (default is 'mat1')
         * @returns the mtl content
         */
        static MTL(mesh: Mesh, materialName?: string): string;
    }




    /** Pure barrel — re-exports only side-effect-free modules */




    export class BVHExporter {
        static Export(skeleton: Skeleton, animationNames?: string[], frameRate?: number): string;
        private static _BuildBoneHierarchy;
        private static _ExportHierarchy;
        private static _IsEndSite;
        private static _GetBoneOffset;
        private static _ExportMotionData;
        private static _CollectFrameValues;
        private static _GetPositionAtFrameIndex;
        private static _GetRotationAtFrameIndex;
        private static _QuaternionToEuler;
    }


    /** Pure barrel — re-exports only side-effect-free modules */




    /**
     * Options controlling how meshes are exported into the 3MF model.
     *
     * Notes:
     * - These flags are kept generic here and are expected to be interpreted by the concrete serializer/model builder.
     * - Defaults are set in AbstractThreeMfSerializer.DEFAULT_3MF_EXPORTER_OPTIONS.
     */
    export interface IThreeMfSerializerOptions extends IThreeMfSerializerBaseOptions {
        /**
         * If true, export mesh instances (multiple references to the same geometry) when supported.
         * If false, geometry may be duplicated depending on the concrete implementation.
         */
        exportInstances?: boolean;
    }
    /**
     * Babylon.js to 3MF serializer.
     *
     * This serializer converts Babylon meshes into a 3MF model, then relies on the base class
     * (AbstractThreeMfSerializer) to package the OPC parts into a zip stream.
     *
     * Design notes:
     * - First pass: export "source" meshes (non-instances) and build an index to map Babylon mesh/submesh to 3MF object id.
     * - Second pass (optional): export instances as additional build items referencing the original object ids.
     * - Submesh export is handled by extracting per-submesh vertex/index buffers so materials/colors can be preserved
     *   by downstream steps that attach per-object properties.
     */
    export class ThreeMfSerializer extends AbstractThreeMfSerializer<Mesh | InstancedMesh, IThreeMfSerializerOptions> {
        /**
         * Default serialization options: meter units, no instance export.
         */
        static DefaultOptions: IThreeMfSerializerOptions;
        /**
         * Babylon's vertex buffer semantic for positions.
         * Babylon uses string-based "kind" keys for vertex buffers.
         */
        private static _PositionKind;
        /**
         * Cached promise so we only attempt to load fflate once.
         * This prevents multiple concurrent LoadScriptAsync calls.
         */
        private _fflateReadyPromise?;
        /**
         * @param opts serializer options (merged with defaults in base class).
         */
        constructor(opts?: Partial<IThreeMfSerializerOptions>);
        /**
         * Build a 3MF model from Babylon meshes.
         *
         * Important: this method should not allocate huge intermediate data unless needed.
         * Submesh extraction does allocate new position/index arrays for each exported submesh.
         * @param builder
         * @param meshes
         * @returns
         */
        toModel(builder: ThreeMfModelBuilder, ...meshes: Array<Mesh | InstancedMesh>): I3mfModel;
        /**
         * Ensure the zip library (fflate) is available in the current runtime.
         *
         * Host assumptions:
         * - This implementation relies on fflate being exposed on globalThis.fflate.
         * - If it is not present, it loads a script from ThreeMfSerializerGlobalConfiguration.FFLATEUrl using Babylon Tools.LoadScriptAsync.
         * @returns
         */
        ensureZipLibReadyAsync(): Promise<any>;
        /**
         * Extract a single SubMesh into a standalone vertex/index buffer pair.
         *
         * Why:
         * - 3MF mesh objects typically reference a contiguous vertex array and triangle indices.
         * - Babylon SubMesh references a slice of the global index buffer, but shares the vertex buffer.
         * - To serialize each submesh independently, we build a compacted vertex buffer containing only the used vertices
         *   and remap indices accordingly.
         *
         * Complexity:
         * - O(indexCount) time, O(uniqueVerticesInSubmesh) additional memory.
         * @param mesh
         * @param sm
         * @returns
         */
        private _extractSubMesh;
        /**
         * Group items by a computed key.
         * Used to group instances by sourceMesh so the resulting XML is easier to read and debug.
         * @param items
         * @param key
         * @returns
         */
        private _groupBy;
        /**
         * Basis conversion from Babylon coordinate system to the expected 3MF coordinate system.
         *
         * Here we rotate +90 degrees around X:
         * - This is commonly used to convert between Y-up and Z-up conventions.
         * - Verify this matches your pipeline (Babylon is typically left-handed Y-up).
         */
        private static readonly _R_BJS_TO_3MF;
        /**
         * Converts a Babylon.js 4x4 matrix into a 3MF 3x4 transform matrix and writes the result into ref.
         *
         * Babylon.js conventions:
         * - Babylon exposes matrices with logical row/column indexing (M(row, column)).
         * - It stores the 16 coefficients in a contiguous array in row-major order:
         *   [ M00, M01, M02, M03,
         *     M10, M11, M12, M13,
         *     M20, M21, M22, M23,
         *     M30, M31, M32, M33 ]
         *
         * 3MF expectation:
         * - 3MF uses an affine transform represented as a 3x4 matrix (12 values).
         * - The values are taken from the first 3 columns of the 4x4 matrix, across the 4 rows:
         *   m00 m01 m02  m10 m11 m12  m20 m21 m22  m30 m31 m32
         *
         * Steps:
         * 1) Compose Babylon transform with the basis change:
         *    tmp = tBjs * _R_BJS_TO_3MF
         * 2) Extract the 12 coefficients in 3MF order from tmp.m.
         *
         * Interop note:
         * - Do not transpose here. We only reorder values to match the 3MF 3x4 serialization order.
         * - Transposition is only relevant when interfacing with code that assumes column-major storage.
         *
         * @param tBjs Babylon.js 4x4 matrix.
         * @param ref Output 3MF 3x4 matrix container (ref.values assigned).
         * @returns ref, for chaining.
         */
        private _handleBabylonTo3mfMatrixTransformToRef;
    }


    /**
     * Class used to store configuration of the 3MF Serializer
     */
    export class ThreeMfSerializerGlobalConfiguration {
        /**
         * Url to use to load the fflate library (for zip compression)
         */
        static FFLATEUrl: string;
    }


    /** Pure barrel — re-exports only side-effect-free modules */




    /**
     *
     */
    export interface IXmlSerializerNumberOptions {
        /**
         *
         */
        eps: number;
        /**
         *
         */
        maxDecimalsCap?: number;
        /**
         *
         */
        trimTrailingZeros?: boolean;
        /**
         *
         */
        fixedDecimals?: number;
        /**
         *
         */
        allowScientific?: boolean;
        /**
         *
         */
        snapNearZero?: boolean;
        /**
         *
         */
        zeroThreshold?: number;
        /**
         *
         */
        perAttributeEps?: Record<string, number>;
    }
    /**
     *
     */
    export interface IXmlSerializerFormatOptions {
        /**
         *
         */
        number?: IXmlSerializerNumberOptions;
    }
    export var DefaultXmlSerializerNumberOptions: Readonly<IXmlSerializerNumberOptions>;
    export var DefaultXmlSerializerFormatOptions: Readonly<IXmlSerializerFormatOptions>;
    /**
     *@param opts
     *@returns
     */
    export function ResolveNumberOptions(opts?: IXmlSerializerNumberOptions): Required<Omit<IXmlSerializerNumberOptions, "perAttributeEps" | "fixedDecimals" | "maxDecimalsCap" | "trimTrailingZeros" | "allowScientific" | "snapNearZero" | "zeroThreshold">> & Pick<IXmlSerializerNumberOptions, "perAttributeEps" | "fixedDecimals"> & {
        maxDecimalsCap: number;
        trimTrailingZeros: boolean;
        allowScientific: boolean;
        snapNearZero: boolean;
        zeroThreshold: number;
    };
    /**
     *@param opts
     *@returns
     */
    export function ResolveFormatOptions(opts?: IXmlSerializerFormatOptions): {
        number: Required<Omit<IXmlSerializerNumberOptions, "maxDecimalsCap" | "trimTrailingZeros" | "fixedDecimals" | "allowScientific" | "snapNearZero" | "zeroThreshold" | "perAttributeEps">> & Pick<IXmlSerializerNumberOptions, "fixedDecimals" | "perAttributeEps"> & {
            maxDecimalsCap: number;
            trimTrailingZeros: boolean;
            allowScientific: boolean;
            snapNearZero: boolean;
            zeroThreshold: number;
        };
    };
    /**
     *
     */
    export class NumberFormatter implements IFormatter<number> {
        o: IXmlSerializerFormatOptions;
        private _o;
        /**
         *
         * @param o
         */
        constructor(o: IXmlSerializerFormatOptions);
        /**
         *
         * @param x
         * @returns
         */
        toString(x: number): string;
        private _clampInt;
    }


    /**
     */
    export class XmlSerializer {
        /** */
        private _format;
        /** */
        private _builder;
        /** */
        private _ns;
        /** */
        private _prefixCount;
        private _nFmt?;
        /**
         *
         * @param builder
         * @param format
         */
        constructor(builder: IXmlBuilder, format?: IXmlSerializerFormatOptions);
        /**
         *
         * @param ns
         * @returns
         */
        withNamespace(...ns: XmlName[]): XmlSerializer;
        /**
         *
         * @param root
         * @param name
         */
        serialize(root: object, name?: XmlName): void;
        private _writeObject;
        private _getPrefix;
        private _writeObjectContent;
        private _gatherNamespaces;
        private _assignNamespace;
        private _buildNsPrefix;
    }


    /** Describes an XML qualified name with an optional namespace. */
    export interface IQualifiedName {
        /** The namespace URI or prefix. */
        ns?: string;
        /** The local XML name. */
        name: string;
    }
    /** Provides a fluent interface for writing XML content. */
    export interface IXmlBuilder {
        /**
         * Writes the XML declaration.
         * @param version defines the XML version
         * @param encoding defines the optional XML encoding
         * @param standalone defines the optional standalone flag
         * @returns the XML builder
         */
        dec(version: string, encoding?: string, standalone?: boolean): IXmlBuilder;
        /**
         * Writes an XML attribute.
         * @param ns defines the attribute namespace
         * @param n defines the attribute name
         * @param v defines the attribute value
         * @returns the XML builder
         */
        att(ns: string | null, n: string, v: string): IXmlBuilder;
        /**
         * Writes an XML element.
         * @param ns defines the element namespace
         * @param n defines the element name
         * @returns the XML builder
         */
        ele(ns: string | null, n: string): IXmlBuilder;
        /**
         * Writes text content.
         * @param txt defines the text to write
         * @returns the XML builder
         */
        text(txt: string): IXmlBuilder;
        /**
         * Ends the current XML element.
         * @returns the XML builder
         */
        end(): IXmlBuilder;
    }
    /**
     * @param x
     * @returns
     */
    export function IsQualifiedName(x: unknown): x is {
        name: string;
    };
    export type XmlName = string | IQualifiedName;
    type FieldKind = "attr" | "elem" | "none";
    /** Formats values for XML serialization. */
    export interface IFormatter<T = any> {
        /**
         * Converts a value to its XML string representation.
         * @param value defines the value to format
         * @returns the XML string representation
         */
        toString(value: T): string;
    }
    export type FormatterCtor<T> = new (args: IXmlSerializerFormatOptions) => IFormatter<T>;
    type FieldMeta = {
        kind: FieldKind;
        prop: string;
        name?: XmlName;
        ignore?: boolean;
        formatter?: FormatterCtor<any>;
    };
    /**
     * @param name
     * @returns
     */
    export function XmlName(name: XmlName): (ctor: Function, _context: ClassDecoratorContext) => void;
    /**
     * tell the serializer to ignore the property
     * @returns
     */
    export function XmlIgnore(): (_value: unknown, context: {
        name: string | symbol;
        metadata: DecoratorMetadataObject;
    }) => void;
    /**
     * tell the serializer to serialize the property as attribute
     * @returns
     */
    export function XmlAttr(opts?: {
        name: XmlName;
        formatter?: FormatterCtor<any>;
    }): (_value: unknown, context: {
        name: string | symbol;
        metadata: DecoratorMetadataObject;
    }) => void;
    /**
     * tell the serializer to serialize the property as element - this is the default behavior but shoud be
     * specified when wanted to update the default name of the classe or if the class is not decorated (without \@XmlName)
     * @returns
     */
    export function XmlElem(opts?: {
        name: XmlName;
    }): (_value: unknown, context: {
        name: string | symbol;
        metadata: DecoratorMetadataObject;
    }) => void;
    /**
     *
     * @param obj
     * @returns
     */
    export function GetXmlFieldMeta(obj: any): FieldMeta[];
    /**
     *
     * @param obj
     * @returns
     */
    export function GetXmlName(obj: any): XmlName | undefined;
    /**
     *
     * @param qn
     * @returns
     */
    export function XmlNameToParts(qn: XmlName): IQualifiedName;
    /**
     *
     * @param name
     * @param prefix
     * @returns
     */
    export function ToQualifiedString(name: string, prefix?: string): string;


    /** */
    export class StringXmlWriter implements IXmlWriter {
        /** */
        count: number;
        private _chunks;
        /**
         * @param data
         * @returns
         */
        write(...data: string[]): IXmlWriter;
        /**
         * @returns
         */
        toString(): string;
        /**
         */
        clear(): void;
    }


    /**
     */
    export interface IXmlWriter {
        /**
         * @param data
         * @returns
         */
        write(...data: string[]): IXmlWriter;
        /** */
        count: number;
        /** */
        clear(): void;
    }
    /** */
    export enum TokenType {
        Declaration = 0,
        Tag = 1,
        Attribute = 2,
        Text = 3
    }
    /** */
    export class XmlBuilder implements IXmlBuilder {
        /** */
        static Context: {
            new (name: string, depth: number): {
                /** */
                name: string;
                /** */
                closed: boolean;
                /** */
                lastToken: TokenType | null;
                /** */
                depth: number;
                ns2prefix: Map<string, string>;
                prefix2ns: Map<string, string>;
                defaultNs: string | null;
            };
        };
        /** */
        private _w;
        /** */
        private _ctxStack;
        /** */
        private _d;
        constructor(w: IXmlWriter);
        /**
         *
         * @param version
         * @param encoding
         * @param standalone
         * @returns
         */
        dec(version: string, encoding?: string, standalone?: boolean): IXmlBuilder;
        /**
         *
         * @param ns
         * @param n
         * @param v
         * @returns
         */
        att(ns: string | null, n: string, v: string): IXmlBuilder;
        /**
         *
         * @param ns
         * @param n
         * @returns
         */
        ele(ns: string | null, n: string): IXmlBuilder;
        /**
         *
         * @param txt
         * @returns
         */
        text(txt: string): IXmlBuilder;
        /**
         *
         * @returns
         */
        end(): IXmlBuilder;
        protected _pushContext(name: string, depth: number): InstanceType<typeof XmlBuilder.Context>;
        protected _popContext(): InstanceType<typeof XmlBuilder.Context> | undefined;
        protected _peekContext(): InstanceType<typeof XmlBuilder.Context> | undefined;
        protected get _contextDepth(): number;
        private _writeAttStr;
        private _lookupPrefix;
        private _escText;
        private _escAttr;
        private _isXmlnsDecl;
        private _registerNamespace;
        private _allocPrefix;
        private _ensurePrefixDeclared;
        private _closeOpenTagIfNeeded;
    }


    /** */
    export type ByteSink = {
        push(chunk: Uint8Array, final?: boolean): void;
    };
    /** */
    export class Utf8XmlWriterToBytes implements IXmlWriter {
        private readonly _sink;
        private readonly _opts;
        /** */
        count: number;
        private _encoder;
        private _pending;
        private _pendingChars;
        constructor(_sink: ByteSink, _opts?: {
            flushChars?: number;
        });
        /**
         * @param data
         * @returns
         */
        write(...data: string[]): IXmlWriter;
        /**
         * @returns
         */
        flush(): this;
        /**
         */
        finish(): void;
        /**
         */
        clear(): void;
    }


    /** Pure barrel — re-exports only side-effect-free modules */




    /** Pure barrel — re-exports only side-effect-free modules */




    /** Alias type for number array or Float32Array */
    export type ThreeMfFloatArray = number[] | Float32Array;
    /** Alias type for number array or Float32Array or Int32Array or Uint32Array or Uint16Array */
    export type ThreeMfIndicesArray = number[] | Int32Array | Uint32Array | Uint16Array;
    /**
     * Interface used to define object data independaly of framework
     */
    export interface I3mfVertexData {
        /**
         * An array of the x, y, z position of each vertex  [...., x, y, z, .....]
         */
        positions: ThreeMfFloatArray | null;
        /**
         * An array of i, j, k the three vertex indices required for each triangular facet  [...., i, j, k .....]
         */
        indices: ThreeMfIndicesArray | null;
        /**
         * An array of the x, y, z normal vector of each vertex  [...., x, y, z, .....]
         */
        normals?: ThreeMfFloatArray | null;
        /**
         * An array of the r, g, b, a, color of each vertex  [...., r, g, b, a, .....]
         */
        colors?: ThreeMfFloatArray | null;
    }
    /**
     * interface used to abstact rgb colors from any framework.
     */
    export interface I3mfRGBAColor {
        /**
         *
         */
        r: number;
        /**
         *
         */
        g: number;
        /**
         *
         */
        b: number;
        /**
         *
         */
        a?: number;
    }


    /**
     * Options controlling how meshes are exported into the 3MF model.
     *
     * Notes:
     * - These flags are kept generic here and are expected to be interpreted by the concrete serializer/model builder.
     * - Defaults are set in AbstractThreeMfSerializer.DEFAULT_3MF_EXPORTER_OPTIONS.
     */
    export interface IThreeMfSerializerBaseOptions {
        /**
         * define the unit. Default is millimeter
         */
        unit?: ST_Unit;
        /**
         *
         */
        metadata?: Record<string, string>;
    }
    /**
     * Minimal contract for a 3MF serializer that can stream its output through a sink callback.
     *
     * The sink callback receives:
     * - err: any error produced by the serialization pipeline (if any)
     * - chunk: a chunk of bytes to append to the destination
     * - final: true when this is the last chunk
     *
     * Important:
     * - Implementations should call sink with final=true exactly once, or rely on the underlying zip lib to do so.
     * - Consumers may ignore final if they just buffer everything.
     */
    export interface I3mfSerializer<T> {
        serializeAsync(sink: (err: any, chunk: Uint8Array, final: boolean) => void, ...meshes: Array<T>): Promise<void>;
    }
    /**
     * Base class for 3MF serialization.
     *
     * Responsibilities:
     * - Convert user meshes to a 3MF model (toModel).
     * - Wrap the 3MF document parts into an OPC container (zip) and stream bytes through the sink.
     *
     * Non-responsibilities:
     * - Providing/initializing the zip implementation (ensureZipLibReadyAsync is abstract).
     * - Defining how meshes map to 3MF objects (toModel is abstract).
     */
    export abstract class AbstractThreeMfSerializer<T, O extends IThreeMfSerializerBaseOptions> implements I3mfSerializer<T> {
        private _o;
        /**
         * @param opts user-provided options overriding defaults.
         */
        constructor(opts: O);
        /**
         * Expose the resolved options (defaults + overrides) as readonly.
         */
        get options(): Readonly<O>;
        /**
         * Generic 3MF binary serializer.
         * Pipeline overview:
         * 1. ensureZipLibReadyAsync provides a zip implementation (host-dependent).
         * 2. Convert meshes into an I3mfDocument (OPC parts + model).
         * 3. Create a zip target that streams through the provided sink.
         * 4. Serialize XML parts into zip entries.
         * 5. End the zip stream.
         * @param sink a callback receiving byte chunks; enables streaming without buffering the full archive in memory.
         * @param meshes the meshes to serialize.
         * @returns
         */
        serializeAsync(sink: (err: any, chunk: Uint8Array, final: boolean) => void, ...meshes: Array<T>): Promise<void>;
        /**
         * Build a full 3MF OPC document from meshes.
         *
         * The default behavior uses ThreeMfDocumentBuilder with the model produced by toModel().
         * Override if you need custom parts (textures, thumbnails, print ticket, etc.).
         * @param meshes
         * @returns
         */
        toDocument(...meshes: Array<T>): I3mfDocument | undefined;
        /**
         * Convert input meshes into a 3MF model.
         *
         * Implementations typically:
         * - Create resources and objects.
         * - Define build items (instances) when exportInstances is enabled.
         * - Encode geometry and properties required by your pipeline.
         */
        abstract toModel(builder: ThreeMfModelBuilder, ...meshes: Array<T>): I3mfModel;
        /**
         * Provide a zip implementation for the current host/runtime.
         *
         * This might be provided by the framework implementation, but it could differ depending on the host
         * (native, Node.js, browser, etc.).
         *
         * Expected shape (fflate-like):
         * - return [ Zip, ZipDeflate ] at minimum.
         *
         * Notes:
         * - In a browser, this might require bundler configuration or dynamic import.
         * - In Node.js, this might be a direct import of "fflate" or another compatible implementation.
         */
        abstract ensureZipLibReadyAsync(): Promise<any>;
    }
    /**
     * Convenience helpers around serializers.
     */
    export class ThreeMf {
        /**
         * Serialize to a single in-memory buffer.
         *
         * This is a helper that buffers all chunks produced by serializeAsync, then concatenates them.
         * Use serializeAsync directly if you want true streaming to a file/response.
         * @param s
         * @param meshes
         * @returns
         */
        static SerializeToMemoryAsync<A>(s: I3mfSerializer<A>, ...meshes: Array<A>): Promise<Uint8Array | undefined>;
    }


    export const OpenXmlContentTypesNamespace = "http://schemas.openxmlformats.org/package/2006/content-types";
    export const OpenXmlRelationshipsNamespace = "http://schemas.openxmlformats.org/package/2006/relationships";
    export enum KnownI3mfContentType {
        Relationships = "application/vnd.openxmlformats-package.relationships+xml",
        Model = "application/vnd.ms-package.3dmanufacturing-3dmodel+xml",
        Materials = "application/vnd.ms-package.3dmanufacturing-material+xml",
        Colors = "application/vnd.ms-package.3dmanufacturing-colors+xml",
        Texture = "application/vnd.ms-package.3dmanufacturing-texture+xml",
        Texture2D = "application/vnd.ms-package.3dmanufacturing-texture2d+xml",
        Production = "application/vnd.ms-package.3dmanufacturing-production+xml",
        Slice = "application/vnd.ms-package.3dmanufacturing-slice+xml",
        BeamLattice = "application/vnd.ms-package.3dmanufacturing-beamlattice+xml",
        SecureContent = "application/vnd.ms-package.3dmanufacturing-securecontent+xml",
        Png = "image/png",
        Jpeg = "image/jpeg",
        Tiff = "image/tiff",
        Xml = "application/xml"
    }
    export const RelationshipDirName = "_rels/";
    export const Object3dDirName = "3D/";
    export const ModelFileName = "3dmodel.model";
    export const RelationshipFileName = ".rels";
    export const ContentTypeFileName = "[Content_Types].xml";
    /**
     * Common OPC and 3MF relationship Type URIs.
     */
    export class Known3mfRelationshipTypes {
        /**
         * 3MF core: points to the main .model part of the package
         */
        static readonly ThreeDimModel = "http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel";
        /**
         * OPC core: points to a package thumbnail (often used by 3MF packages)
         */
        static readonly Thumbnail = "http://schemas.openxmlformats.org/package/2006/relationships/metadata/thumbnail";
        /**
         * 3MF (print ticket): optional printing settings part (rarely used by slicers)
         */
        static readonly PrintTicket = "http://schemas.microsoft.com/3dmanufacturing/2013/01/printticket";
        /**
         * OPC core: indicates parts that must be preserved when editing the package
         */
        static readonly MustPreserve = "http://schemas.openxmlformats.org/package/2006/relationships/mustpreserve";
        /**
         * Convenience set for quick checks
         */
        static readonly Known: ReadonlySet<string>;
        /**
         * Test if the relationship Type is one of the common known URIs above
         * @param type
         * @returns true if the relationship Type is one of the common known URIs above
         */
        static IsKnown(type: string): boolean;
        /**
         * test if the relationship Type is the main 3MF model entry point
         * @param type
         * @returns  true if the relationship Type is the main 3MF model entry point
         */
        static IsThreeDimModel(type: string): boolean;
    }
    /**
     *
     */
    export interface I3mfContentTypes {
        /**
         *
         */
        items: I3mfContentType[];
    }
    /**
     *
     */
    export interface I3mfContentType {
        /**
         *
         */
        ext: string;
        /**
         *
         */
        ct: string;
    }
    /**
     *
     */
    export interface I3mfRelationships {
        /**
         *
         */
        items: I3mfRelationship[];
    }
    /**
     *
     */
    export interface I3mfRelationship {
        /**
         *
         */
        id: string;
        /**
         *
         */
        type?: string;
        /**
         *
         */
        target?: string;
    }
    /**
     *
     */
    export interface I3mfDocument {
        /**
         *
         */
        contentTypes: I3mfContentTypes;
        /**
         *
         */
        relationships: I3mfRelationships;
        /**
         *
         */
        model: I3mfModel;
    }


    /**
     *
     */
    export class ThreeMfContentTypes implements I3mfContentTypes {
        /**
         *
         */
        items: ThreeMfContentType[];
    }
    /**
     *
     */
    export class ThreeMfContentType implements I3mfContentType {
        /**
         *
         */
        ext: string;
        /**
         *
         */
        ct: string;
        /**
         *
         * @param ext
         * @param ct
         */
        constructor(ext: string, ct: string);
    }
    /**
     *
     */
    export class ThreeMfRelationships implements I3mfRelationships {
        /**
         *
         */
        items: ThreeMfRelationship[];
    }
    /**
     *
     */
    export class ThreeMfRelationship implements I3mfRelationship {
        /**
         *
         */
        id: string;
        /**
         *
         */
        type?: string;
        /**
         *
         */
        target?: string;
        constructor(id: string, type: string, target: string);
    }
    /**
     *
     */
    export class ThreeMfDocument implements I3mfDocument {
        contentTypes: I3mfContentTypes;
        relationships: I3mfRelationships;
        model: I3mfModel;
        constructor(contentTypes: I3mfContentTypes, relationships: I3mfRelationships, model: I3mfModel);
    }


    /**
     * XML namespace for the core 3MF model schema.
     * This is the default namespace used by <model> and most standard 3MF elements.
     */
    export const ThreeDimModelNamespace = "http://schemas.microsoft.com/3dmanufacturing/core/2015/02";
    /**
     * XML namespace for the TriangleSets extension (2021/07).
     * This extension is used for more advanced triangle/property use cases.
     * Only declare/use it when you actually emit elements/attributes that require it.
     */
    export const TriangleSetsNamespace = "http://schemas.microsoft.com/3dmanufacturing/trianglesets/2021/07";
    /**
     * 3MF model units.
     * The unit affects interpretation of vertex coordinates (x,y,z).
     * Most pipelines use millimeter, but the writer should match the upstream scene unit expectations.
     */
    export enum ST_Unit {
        micron = "micron",
        millimeter = "millimeter",
        centimeter = "centimeter",
        inch = "inch",
        foot = "foot",
        meter = "meter"
    }
    /**
     * In the XSD, ST_Matrix3D is a whitespace separated list of numbers.
     * The official 3MF core spec uses a 3x4 matrix (12 numbers).
     */
    export type ST_Matrix3D = [number, number, number, number, number, number, number, number, number, number, number, number];
    /**
     *
     */
    export interface IMatrix3d {
        /** */
        values: ST_Matrix3D;
    }
    /**
     * 3MF color value.
     * In the 3MF core spec, colors are typically expressed as sRGB hex strings: "#RRGGBB" (and sometimes "#AARRGGBB").
     * This type is kept as string because we serialize directly into XML and want to avoid coupling to a specific color class.
     */
    export type ST_ColorValue = string;
    /**
     * URI reference type used by attributes like thumbnail.
     * Usually a relative package path inside the OPC container, for example "/Metadata/thumbnail.png".
     */
    export type ST_UriReference = string;
    /**
     * Numeric type used for coordinates and similar scalar values.
     * 3MF stores numbers as XML attributes/text; here we represent them as JS numbers.
     */
    export type ST_Number = number;
    /**
     * Resource identifiers used by <object id="...">, property groups, etc.
     * This is usually a positive integer unique within the model.
     */
    export type ST_ResourceID = number;
    /**
     * Resource index used to reference an entry within a resource list.
     * For example, triangle v1/v2/v3 reference indices into <vertices>.
     */
    export type ST_ResourceIndex = number;
    /**
     * Standard 3MF object type.
     * This is optional in 3MF; if omitted, consumers often treat it as "model".
     */
    export enum ST_ObjectType {
        model = "model",
        solidsupport = "solidsupport",
        support = "support",
        surface = "surface",
        other = "other"
    }
    /**
     * Generic metadata entry.
     * Metadata can appear at the model level (<metadata>) and inside metadata groups (<metadatagroup>).
     *
     * Notes:
     * - "name" is the metadata key.
     * - "type" is optional and can be a MIME type or a schema indicator depending on usage.
     * - "preserve" instructs consumers whether to keep metadata when modifying the model.
     */
    export interface I3mfMetadata {
        /** Metadata key (required). */
        name: string;
        /** If true, indicates the metadata should be preserved by consumers (optional). */
        preserve?: boolean;
        /** Optional type information for the value. */
        type?: string;
        /** Metadata value (required). */
        value: string;
    }
    /**
     * A grouping element for metadata.
     * Used in some places where the schema allows a metadata group rather than raw metadata entries.
     */
    export interface I3mfMetadataGroup {
        /** The list of metadata entries contained in the group. */
        metadata: Array<I3mfMetadata>;
    }
    /**
     * 3MF vertex.
     * Coordinates are expressed in the model unit (I3mfModel.unit).
     */
    export interface I3mfVertex {
        /** X coordinate. */
        x: ST_Number;
        /** Y coordinate. */
        y: ST_Number;
        /** Z coordinate. */
        z: ST_Number;
    }
    /**
     * 3MF triangle.
     * v1/v2/v3 are indices into the vertices list (<vertices> \<vertex .../\>...</vertices>).
     *
     * Property assignment:
     * - pid and p1/p2/p3 are used to assign per-triangle or per-vertex properties (like materials or colors),
     *   depending on which property group pid refers to.
     */
    export interface I3mfTriangle {
        /** Index of first vertex in the vertices array. */
        v1: ST_ResourceIndex;
        /** Index of second vertex in the vertices array. */
        v2: ST_ResourceIndex;
        /** Index of third vertex in the vertices array. */
        v3: ST_ResourceIndex;
        /**
         * Optional per-vertex property indices for v1/v2/v3.
         * These are indices into the property group's entry list (the group referenced by pid).
         */
        p1?: ST_ResourceIndex;
        /** */
        p2?: ST_ResourceIndex;
        /** */
        p3?: ST_ResourceIndex;
        /**
         * Property group id for this triangle.
         * If present, it overrides the object-level pid for this specific triangle.
         */
        pid?: ST_ResourceID;
    }
    /**
     * Container for vertices.
     * Matches the XML structure <vertices>\<vertex .../\>...</vertices>.
     */
    export interface I3mfVertices {
        /** Array of vertices. Order matters because triangles reference indices. */
        vertex: Array<I3mfVertex>;
    }
    /**
     * Container for triangles.
     * Matches the XML structure <triangles>\<triangle .../\>...</triangles>.
     */
    export interface I3mfTriangles {
        /** Array of triangles. */
        triangle: Array<I3mfTriangle>;
    }
    /**
     * Mesh geometry content for an object.
     * Exactly one of: mesh content OR components content should be provided in an object.
     */
    export interface I3mfMesh {
        /** Vertex list. */
        vertices: I3mfVertices;
        /** Triangle list. */
        triangles: I3mfTriangles;
    }
    /**
     * Component reference inside a composite object.
     * A composite object is an object whose content is <components> rather than <mesh>.
     *
     * objectid references another object in resources.
     * transform (3x4) positions that referenced object within the composite.
     */
    export interface I3mfComponent {
        /** Referenced object id. */
        objectid: ST_ResourceID;
        /**
         * Optional transform applied to the referenced object within the component.
         * Represented as a 3x4 matrix.
         */
        transform?: IMatrix3d;
    }
    /**
     * Container for components.
     * Matches <components><component objectid="..."/></components>.
     */
    export interface I3mfComponents {
        /** Array of component references. */
        component: Array<I3mfComponent>;
    }
    /**
     * Object resource.
     * An object either contains a mesh (geometry) or components (composite object).
     *
     * Properties (pid/pindex):
     * - pid references a property group (e.g. basematerials id).
     * - pindex is an index within that group.
     * - If pindex is used, pid is required.
     *
     * Metadata:
     * - metadatagroup is optional and can store additional object-level metadata.
     */
    export interface I3mfObject {
        /** Unique object id within the model. */
        id: ST_ResourceID;
        /** Optional object type hint. */
        type?: ST_ObjectType;
        /** Optional thumbnail reference (usually a package path). */
        thumbnail?: ST_UriReference;
        /** Optional part number (often used by manufacturing systems). */
        partnumber?: string;
        /** Optional human-readable name. */
        name?: string;
        /**
         * Property group reference.
         * Example: <basematerials id="5"> ... </basematerials> then pid=5.
         * Required if pindex is specified.
         */
        pid?: ST_ResourceID;
        /**
         * Index inside the property group referenced by pid.
         * Meaning depends on the property group type (base materials, color group, etc.).
         */
        pindex?: ST_ResourceIndex;
        /** Optional grouped metadata for the object. */
        metadatagroup?: I3mfMetadataGroup;
        /**
         * Content of the object:
         * - Mesh geometry OR
         * - Components (composite object).
         *
         * In the 3MF XML schema, this corresponds to having either a <mesh> element or a <components> element.
         */
        content?: I3mfMesh | I3mfComponents;
    }
    /**
     * A single base material entry.
     * "name" is a label, "displaycolor" provides the color used for rendering previews.
     */
    export interface I3mfBase {
        /** Material name/label. */
        name: string;
        /** Display color for the base material. */
        displaycolor: ST_ColorValue;
    }
    /**
     * Base materials property group.
     * Triangles or objects can reference this group via pid, and then a specific entry via pindex (or p1/p2/p3).
     */
    export interface I3mfBaseMaterials {
        /** Property group id. Must be unique within resources. */
        id: ST_ResourceID;
        /** List of base material entries. */
        base: Array<I3mfBase>;
    }
    /**
     * Model resources container.
     * Holds object resources and optional property groups such as basematerials.
     */
    export interface I3mfResources {
        /** All objects available for build items and components. */
        object: Array<I3mfObject>;
        /**
         * Optional base materials groups.
         * Other property groups may exist in 3MF (colors, textures, etc.) but are not modeled here.
         */
        basematerials?: Array<I3mfBaseMaterials>;
    }
    /**
     * Build item.
     * The build section describes what to "print" or "instantiate" from the resources.
     *
     * objectid references a resource object, and transform places it in the world.
     * partnumber and metadatagroup allow attaching build-item specific info.
     */
    export interface I3mfItem {
        /** Referenced object id to build. */
        objectid: ST_ResourceID;
        /** Optional placement transform (3x4). */
        transform?: IMatrix3d;
        /** Optional part number at the build item level. */
        partnumber?: string;
        /** Optional build-item metadata. */
        metadatagroup?: I3mfMetadataGroup;
    }
    /**
     * Build container.
     * Contains all build items.
     */
    export interface I3mfBuild {
        /** Array of build items. */
        item: Array<I3mfItem>;
    }
    /**
     * Root model element.
     *
     * Extensions:
     * - requiredextensions: a space-separated list of prefixes (or namespaces depending on your serializer conventions)
     *   that are required to interpret the model.
     * - recommendedextensions: extensions that improve fidelity but are not required.
     *
     * Notes:
     * - resources and build are typically present in a valid printable model.
     * - metadata at the model level stores global information like title, author, etc.
     */
    export interface I3mfModel {
        /** Unit used for all coordinates in the model. */
        unit?: ST_Unit;
        /** Declares extensions that must be understood by consumers. */
        requiredextensions?: string;
        /** Declares extensions that may be used for better results. */
        recommendedextensions?: string;
        /** Optional model-level metadata entries. */
        metadata?: Array<I3mfMetadata>;
        /** Optional resources section (objects, materials, etc.). */
        resources?: I3mfResources;
        /** Optional build section (what to instantiate/print). */
        build?: I3mfBuild;
    }


    /**
     *
     */
    export class Matrix3d implements IMatrix3d {
        values: ST_Matrix3D;
        /**
         *
         * @returns
         */
        static Zero(): Matrix3d;
        /**
         *
         * @param values
         */
        constructor(values: ST_Matrix3D);
        /**
         *
         * @returns
         */
        toString(): string;
    }
    /**
     *
     */
    export class MatrixFormatter implements IFormatter<Matrix3d> {
        o: IXmlSerializerFormatOptions;
        /**
         *
         */
        _f: NumberFormatter;
        constructor(o: IXmlSerializerFormatOptions);
        toString(x: Matrix3d): string;
    }
    /**
     *
     */
    export class ThreeMfModel implements I3mfModel {
        /**
         *
         */
        static KnownMeta: Array<string>;
        /**
         *
         */
        unit: ST_Unit;
        /**
         *
         */
        requiredextensions?: string;
        /**
         *
         */
        recommendedextensions?: string;
        /**
         *
         */
        metadata?: Array<I3mfMetadata>;
        /**
         *
         */
        resources?: I3mfResources;
        /**
         *
         */
        build?: I3mfBuild;
    }
    /**
     *
     */
    export class ThreeMfMeta implements I3mfMetadata {
        /**
         *
         */
        name: string;
        /**
         *
         */
        preserve?: boolean;
        /**
         *
         */
        type?: string;
        /**
         *
         */
        value: string;
        /**
         *
         * @param name
         * @param value
         * @param preserve
         * @param type
         */
        constructor(name: string, value: string, preserve?: boolean, type?: string);
    }
    /**
     *
     */
    export class ThreeMfMetadataGroup implements I3mfMetadataGroup {
        /**
         *
         */
        metadata: Array<I3mfMetadata>;
    }
    /**
     *
     */
    export class ThreeMfResources implements I3mfResources {
        /**
         *
         */
        object: Array<I3mfObject>;
        /**
         *
         */
        basematerials?: Array<I3mfBaseMaterials>;
    }
    /**
     *
     */
    export class ThreeMfObject implements I3mfObject {
        /**
         *
         */
        id: ST_ResourceID;
        /**
         *
         */
        type?: ST_ObjectType;
        /**
         *
         */
        thumbnail?: ST_UriReference;
        /**
         *
         */
        partnumber?: string;
        /**
         *
         */
        name?: string;
        /**
         *
         */
        pid?: ST_ResourceID;
        /**
         *
         */
        pindex?: ST_ResourceIndex;
        /**
         *
         */
        metadatagroup?: I3mfMetadataGroup;
        /**
         *
         */
        content?: I3mfMesh | I3mfComponents;
        constructor(id: ST_ResourceID, type?: ST_ObjectType);
    }
    /**
     *
     */
    export class ThreeMfMesh implements I3mfMesh {
        /**
         *
         */
        vertices: I3mfVertices;
        /**
         *
         */
        triangles: I3mfTriangles;
        constructor(vertices?: I3mfVertices, triangles?: I3mfTriangles);
    }
    /**
     *
     */
    export class ThreeMfVertices implements I3mfVertices {
        /**
         *
         */
        vertex: Array<I3mfVertex>;
    }
    /**
     *
     */
    export class ThreeMfVertex implements I3mfVertex {
        /**
         *
         */
        x: ST_Number;
        /**
         *
         */
        y: ST_Number;
        /**
         *
         */
        z: ST_Number;
        constructor(x?: ST_Number, y?: ST_Number, z?: ST_Number);
    }
    /**
     *
     */
    export class ThreeMfTriangles implements I3mfTriangles {
        /**
         *
         */
        triangle: Array<I3mfTriangle>;
    }
    /**
     *
     */
    export class ThreeMfTriangle implements I3mfTriangle {
        /**
         *
         */
        v1: ST_ResourceIndex;
        /**
         *
         */
        v2: ST_ResourceIndex;
        /**
         *
         */
        v3: ST_ResourceIndex;
        /**
         *
         */
        p1?: ST_ResourceIndex;
        /**
         *
         */
        p2?: ST_ResourceIndex;
        /**
         *
         */
        p3?: ST_ResourceIndex;
        /**
         *
         */
        pid?: ST_ResourceID;
        constructor(v1: ST_ResourceIndex, v2: ST_ResourceIndex, v3: ST_ResourceIndex);
    }
    /**
     *
     */
    export class ThreeMfComponents implements I3mfComponents {
        /**
         *
         */
        component: Array<I3mfComponent>;
    }
    /**
     *
     */
    export class ThreeMfComponent implements I3mfComponent {
        /**
         *
         */
        objectid: ST_ResourceID;
        /**
         *
         */
        transform?: Matrix3d;
        constructor(objectid: ST_ResourceID, transform?: Matrix3d);
    }
    /**
     *
     */
    export class ThreeMfBaseMaterials implements I3mfBaseMaterials {
        /**
         *
         */
        id: ST_ResourceID;
        /**
         *
         */
        base: Array<I3mfBase>;
        constructor(id: ST_ResourceID);
    }
    /**
     *
     */
    export class ThreeMfBase implements I3mfBase {
        /**
         *
         */
        name: string;
        /**
         *
         */
        displaycolor: ST_ColorValue;
        constructor(name: string, displaycolor: ST_ColorValue);
    }
    /**
     *
     */
    export class ThreeMfBuild implements I3mfBuild {
        /**
         *
         */
        item: Array<I3mfItem>;
    }
    /**
     *
     */
    export class ThreeMfItem implements I3mfItem {
        /**
         *
         */
        objectid: ST_ResourceID;
        /**
         *
         */
        transform?: Matrix3d;
        /**
         *
         */
        partnumber?: string;
        /**
         *
         */
        metadatagroup?: I3mfMetadataGroup;
        constructor(objectid: ST_ResourceID, transform?: Matrix3d, partnumber?: string);
    }


    /**
     * Handler invoked for every vertex generated by a {@link ThreeMfMeshBuilder}, allowing it to be transformed before export.
     */
    export type VertexHandler = (vertex: I3mfVertex) => I3mfVertex;
    /**
     * Handler invoked for every triangle generated by a {@link ThreeMfMeshBuilder}, allowing it to be transformed before export.
     */
    export type TriangleHandler = (triangle: I3mfTriangle) => I3mfTriangle;
    /**
     * Fluent builder for a 3MF object resource.
     * An object is the base resource of a 3MF model and is either a mesh or a set of components.
     */
    export class ThreeMfObjectBuilder {
        /**
         * The 3MF object resource currently being built.
         */
        protected _object: ThreeMfObject;
        /**
         * Creates a new object builder.
         * @param id The unique resource id of the object within the model.
         * @param type The 3MF object type (model, support, solidsupport, surface or other).
         */
        constructor(id: ST_ResourceID, type: ST_ObjectType);
        /**
         * Sets the human readable name of the object.
         * @param name The name to assign to the object.
         * @returns This builder, to allow chaining.
         */
        withName(name: string): ThreeMfObjectBuilder;
        /**
         * Sets the thumbnail of the object.
         * @param thumbnail The package relative path of the thumbnail part.
         * @returns This builder, to allow chaining.
         */
        withThumbnail(thumbnail: string): ThreeMfObjectBuilder;
        /**
         * Assigns the property resource used by the object.
         * @param id The resource id of the property group (for example a base materials group).
         * @param index The zero based index of the property within the group. Defaults to 0.
         * @returns This builder, to allow chaining.
         */
        withProperty(id: ST_ResourceIndex, index?: number): ThreeMfObjectBuilder;
        /**
         * Returns the object that has been built.
         * @returns The built 3MF object resource.
         */
        build(): I3mfObject;
        /**
         * Discards the current object and starts building a new one.
         * @param id The unique resource id of the new object.
         * @param type The 3MF object type of the new object.
         */
        reset(id: ST_ResourceID, type: ST_ObjectType): void;
    }
    /**
     * Fluent builder for a 3MF object made of components.
     * A components object references other objects instead of defining its own geometry.
     */
    export class ThreeMfComponentsBuilder extends ThreeMfObjectBuilder {
        /**
         * Creates a new components object builder.
         * @param id The unique resource id of the object within the model.
         * @param type The 3MF object type. Defaults to `ST_ObjectType.model`.
         */
        constructor(id: ST_ResourceID, type?: ST_ObjectType);
        /**
         * Adds a component referencing another object resource.
         * @param id The resource id of the referenced object.
         * @param t The optional transform applied to the referenced object.
         * @returns This builder, to allow chaining.
         */
        withComponent(id: ST_ResourceID, t?: Matrix3d): ThreeMfComponentsBuilder;
    }
    /**
     * Fluent builder for a 3MF object holding a mesh.
     * Vertices and triangles are generated from Babylon vertex data and can be post processed through handlers.
     */
    export class ThreeMfMeshBuilder extends ThreeMfObjectBuilder {
        /**
         * Optional handler invoked for every vertex before it is added to the mesh.
         */
        _vh?: VertexHandler;
        /**
         * Optional handler invoked for every triangle before it is added to the mesh.
         */
        _th?: TriangleHandler;
        /**
         * Creates a new mesh object builder.
         * @param id The unique resource id of the object within the model.
         */
        constructor(id: ST_ResourceID);
        /**
         * Registers the handlers used to post process the generated geometry.
         * @param vertex The handler invoked for every generated vertex.
         * @param triangle The optional handler invoked for every generated triangle.
         * @returns This builder, to allow chaining.
         */
        withPostProcessHandlers(vertex: VertexHandler, triangle?: TriangleHandler): ThreeMfMeshBuilder;
        /**
         * Builds the mesh content of the object from the provided vertex data.
         * @param data The positions and indices used to generate the mesh.
         * @returns This builder, to allow chaining.
         */
        withData(data: I3mfVertexData): ThreeMfMeshBuilder;
        /**
         * Assigns the material used by the mesh.
         * @param id The resource id of the base materials group.
         * @param i The zero based index of the material within the group.
         * @returns This builder, to allow chaining.
         */
        withMaterial(id: ST_ResourceID, i: number): ThreeMfMeshBuilder;
        /**
         * Converts vertex data into a 3MF mesh.
         * @param data The positions and indices used to generate the mesh.
         * @returns The generated 3MF mesh.
         */
        private _buildMesh;
        /**
         * Converts a flat position array into a 3MF vertex list, applying the vertex handler when one is registered.
         * @param p The flat array of x, y and z positions.
         * @returns The generated 3MF vertex list.
         */
        private _buildVertices;
        /**
         * Converts a flat index array into a 3MF triangle list, applying the triangle handler when one is registered.
         * @param indice The flat array of vertex indices, three per triangle.
         * @returns The generated 3MF triangle list.
         */
        private _buildTriangle;
    }
    /**
     * Fluent builder for a 3MF base materials resource.
     * Colors are stored as sRGB hexadecimal strings as required by the 3MF specification.
     */
    export class ThreeMfMaterialBuilder {
        private _m;
        /**
         * Creates a new base materials builder.
         * @param id The unique resource id of the base materials group within the model.
         */
        constructor(id: ST_ResourceID);
        /**
         * Adds a named color to the group, or updates it when the name already exists.
         * @param name The name of the material. The lookup is case insensitive.
         * @param color The linear RGBA color, converted to an sRGB hexadecimal string.
         * @returns This builder, to allow chaining.
         */
        withColor(name: string, color: I3mfRGBAColor): ThreeMfMaterialBuilder;
        /**
         * Returns the base materials group that has been built.
         * @returns The built base materials resource.
         */
        build(): I3mfBaseMaterials;
        /**
         * Converts a linear color into the sRGB hexadecimal string used by 3MF.
         * @param c The linear color to convert. The alpha channel is optional.
         * @returns The color as `#RRGGBB`, or `#RRGGBBAA` when an alpha channel is provided.
         */
        private _rgbaToHex;
    }
    /**
     * Fluent builder for a 3MF model, the root part of a 3MF document.
     * It aggregates the resources (materials, meshes and components) and the build items that reference them.
     */
    export class ThreeMfModelBuilder {
        /**
         * The lower cased set of the metadata names defined by the 3MF specification.
         */
        static KnownMetaSet: Set<string>;
        /**
         * The 3MF model currently being built.
         */
        _model: ThreeMfModel;
        /**
         * The object resources added to the model, indexed by resource id.
         */
        _objects: Map<string, I3mfObject>;
        /**
         * Adds a metadata entry to the model.
         * @param name The metadata name. Names outside of the 3MF specification must be namespace qualified.
         * @param value The metadata value.
         * @param preserve Whether consumers must preserve this entry when editing the document.
         * @param type The XML schema type of the value. Defaults to `xs:string`.
         * @returns This builder, to allow chaining.
         */
        withMetaData(name: string, value: string, preserve?: boolean, type?: string): ThreeMfModelBuilder;
        /**
         * Adds a base materials group to the model resources.
         * @param material The base materials resource, or a builder that produces one.
         * @returns This builder, to allow chaining.
         */
        withMaterial(material: I3mfBaseMaterials | ThreeMfMaterialBuilder): ThreeMfModelBuilder;
        /**
         * Adds a mesh object to the model resources.
         * @param object The object resource, or a builder that produces one.
         * @returns This builder, to allow chaining.
         */
        withMesh(object: I3mfObject | ThreeMfMeshBuilder): ThreeMfModelBuilder;
        /**
         * Adds a components object to the model resources.
         * @param components The object resource, or a builder that produces one.
         * @returns This builder, to allow chaining.
         */
        withComponents(components: I3mfObject | ThreeMfComponentsBuilder): ThreeMfModelBuilder;
        /**
         * Adds a build item, which places an object resource in the build plate.
         * @param objectid The resource id of the object to place.
         * @param transform The optional transform applied to the object.
         * @param partnumber The optional part number identifying the produced part.
         * @returns This builder, to allow chaining.
         */
        withBuild(objectid: ST_ResourceID, transform?: Matrix3d, partnumber?: string): ThreeMfModelBuilder;
        /**
         * Sets the unit in which the model coordinates are expressed.
         * @param unit The 3MF unit (micron, millimeter, centimeter, inch, foot or meter).
         * @returns This builder, to allow chaining.
         */
        withUnit(unit: ST_Unit): ThreeMfModelBuilder;
        /**
         * Discards the current model and starts building a new one.
         * @returns This builder, to allow chaining.
         */
        reset(): ThreeMfModelBuilder;
        /**
         * Validates and returns the model that has been built.
         * @returns The built 3MF model.
         * @throws When the model has no object resource or no build item.
         */
        build(): ThreeMfModel;
    }
    /**
     * Fluent builder for a 3MF document, the OPC package that wraps the model.
     * It gathers the content types, the relationships and the model part.
     */
    export class ThreeMfDocumentBuilder {
        private _cts?;
        private _rs?;
        private _m?;
        /**
         * Declares an OPC content type. Duplicate declarations are ignored.
         * @param type The extension to content type mapping to declare.
         * @returns This builder, to allow chaining.
         */
        withContentType(type: I3mfContentType): ThreeMfDocumentBuilder;
        /**
         * Adds an OPC relationship and ensures the relationships content type is declared.
         * Relationships with an already registered id are ignored.
         * @param rel The relationship to add.
         * @returns This builder, to allow chaining.
         */
        withRelationship(rel: I3mfRelationship): ThreeMfDocumentBuilder;
        /**
         * Sets the model part of the document and ensures the model content type is declared.
         * @param m The model resource, or a builder that produces one.
         * @returns This builder, to allow chaining.
         */
        withModel(m: I3mfModel | ThreeMfModelBuilder): ThreeMfDocumentBuilder;
        /**
         * Validates and returns the document that has been built.
         * A default relationship pointing at the model part is generated when none was provided.
         * @returns The built 3MF document.
         * @throws When no model has been set.
         */
        build(): I3mfDocument;
    }



}


                