
declare namespace BABYLON {


    export class WaterMaterial extends PushMaterial {
        renderTargetSize: Vector2;
        private _bumpTexture;
        accessor bumpTexture: BaseTexture;
        diffuseColor: Color3;
        specularColor: Color3;
        specularPower: number;
        private _disableLighting;
        accessor disableLighting: boolean;
        private _maxSimultaneousLights;
        accessor maxSimultaneousLights: number;
        /**
         * Defines the wind force.
         */
        windForce: number;
        /**
         * Defines the direction of the wind in the plane (X, Z).
         */
        windDirection: Vector2;
        /**
         * Defines the height of the waves.
         */
        waveHeight: number;
        /**
         * Defines the bump height related to the bump map.
         */
        bumpHeight: number;
        /**
         * Defines wether or not: to add a smaller moving bump to less steady waves.
         */
        private _bumpSuperimpose;
        accessor bumpSuperimpose: boolean;
        /**
         * Defines wether or not color refraction and reflection differently with .waterColor2 and .colorBlendFactor2. Non-linear (physically correct) fresnel.
         */
        private _fresnelSeparate;
        accessor fresnelSeparate: boolean;
        /**
         * Defines wether or not bump Wwves modify the reflection.
         */
        private _bumpAffectsReflection;
        accessor bumpAffectsReflection: boolean;
        /**
         * Defines the water color blended with the refraction (near).
         */
        waterColor: Color3;
        /**
         * Defines the blend factor related to the water color.
         */
        colorBlendFactor: number;
        /**
         * Defines the water color blended with the reflection (far).
         */
        waterColor2: Color3;
        /**
         * Defines the blend factor related to the water color (reflection, far).
         */
        colorBlendFactor2: number;
        /**
         * Defines the maximum length of a wave.
         */
        waveLength: number;
        /**
         * Defines the waves speed.
         */
        waveSpeed: number;
        /**
         * Defines the number of times waves are repeated. This is typically used to adjust waves count according to the ground's size where the material is applied on.
         */
        waveCount: number;
        /**
         * Sets or gets whether or not automatic clipping should be enabled or not. Setting to true will save performances and
         * will avoid calculating useless pixels in the pixel shader of the water material.
         */
        disableClipPlane: boolean;
        /**
         * Defines whether or not to use world coordinates for wave deformations.
         * The default value is false, meaning that the deformation is applied in object (local) space.
         * You will probably need to set it to true if you are using instances or thin instances for your water objects.
         */
        private _useWorldCoordinatesForWaveDeformation;
        accessor useWorldCoordinatesForWaveDeformation: boolean;
        protected _renderTargets: SmartArray<RenderTargetTexture>;
        private _mesh;
        private _refractionRTT;
        private _reflectionRTT;
        private _reflectionTransform;
        private _offsetMirror;
        private _tempPlane;
        private _lastTime;
        private static readonly _ShaderLoader;
        private _lastDeltaTime;
        private _waitingRenderList;
        private _imageProcessingConfiguration;
        private _imageProcessingObserver;
        /**
         * Gets a boolean indicating that current material needs to register RTT
         */
        get hasRenderTargetTextures(): boolean;
        /**
         * Constructor
         * @param name
         * @param scene
         * @param renderTargetSize
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, renderTargetSize?: Vector2, forceGLSL?: boolean);
        get refractionTexture(): Nullable<RenderTargetTexture>;
        get reflectionTexture(): Nullable<RenderTargetTexture>;
        addToRenderList(node: any): void;
        removeFromRenderList(node: any): void;
        enableRenderTargets(enable: boolean): void;
        getRenderList(): Nullable<AbstractMesh[]>;
        get renderTargetsEnabled(): boolean;
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        private _createRenderTargets;
        getAnimatables(): IAnimatable[];
        getActiveTextures(): BaseTexture[];
        hasTexture(texture: BaseTexture): boolean;
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): WaterMaterial;
        serialize(): any;
        getClassName(): string;
        static Parse(source: any, scene: Scene, rootUrl: string): WaterMaterial;
        static CreateDefaultMesh(name: string, scene: Scene): Mesh;
    }


    /** @internal */
    export var waterVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var waterPixelShader: {
        name: string;
        shader: string;
    };




    /** @internal */
    export var waterVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var waterPixelShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var triplanarVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var triplanarPixelShader: {
        name: string;
        shader: string;
    };


    export class TriPlanarMaterial extends PushMaterial {
        mixTexture: BaseTexture;
        private _diffuseTextureX;
        accessor diffuseTextureX: BaseTexture;
        private _diffuseTextureY;
        accessor diffuseTextureY: BaseTexture;
        private _diffuseTextureZ;
        accessor diffuseTextureZ: BaseTexture;
        private _normalTextureX;
        accessor normalTextureX: BaseTexture;
        private _normalTextureY;
        accessor normalTextureY: BaseTexture;
        private _normalTextureZ;
        accessor normalTextureZ: BaseTexture;
        tileSize: number;
        diffuseColor: Color3;
        specularColor: Color3;
        specularPower: number;
        private _disableLighting;
        accessor disableLighting: boolean;
        private _maxSimultaneousLights;
        accessor maxSimultaneousLights: number;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a TriPlanar Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        getAnimatables(): IAnimatable[];
        getActiveTextures(): BaseTexture[];
        hasTexture(texture: BaseTexture): boolean;
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): TriPlanarMaterial;
        serialize(): any;
        getClassName(): string;
        static Parse(source: any, scene: Scene, rootUrl: string): TriPlanarMaterial;
    }




    /** @internal */
    export var triplanarVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var triplanarPixelShaderWGSL: {
        name: string;
        shader: string;
    };


    export class TerrainMaterial extends PushMaterial {
        private _mixTexture;
        accessor mixTexture: BaseTexture;
        private _diffuseTexture1;
        accessor diffuseTexture1: Texture;
        private _diffuseTexture2;
        accessor diffuseTexture2: Texture;
        private _diffuseTexture3;
        accessor diffuseTexture3: Texture;
        private _bumpTexture1;
        accessor bumpTexture1: Texture;
        private _bumpTexture2;
        accessor bumpTexture2: Texture;
        private _bumpTexture3;
        accessor bumpTexture3: Texture;
        diffuseColor: Color3;
        specularColor: Color3;
        specularPower: number;
        private _disableLighting;
        accessor disableLighting: boolean;
        private _maxSimultaneousLights;
        accessor maxSimultaneousLights: number;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a Terrain Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        getAnimatables(): IAnimatable[];
        getActiveTextures(): BaseTexture[];
        hasTexture(texture: BaseTexture): boolean;
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): TerrainMaterial;
        serialize(): any;
        getClassName(): string;
        static Parse(source: any, scene: Scene, rootUrl: string): TerrainMaterial;
    }


    /** @internal */
    export var terrainVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var terrainPixelShader: {
        name: string;
        shader: string;
    };




    /** @internal */
    export var terrainVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var terrainPixelShaderWGSL: {
        name: string;
        shader: string;
    };


    /**
     * Max value the sky shader may write before the bound render target stores it as +Inf (which would
     * corrupt anything reading the texture back, e.g. an IBL CDF). Derived from the RT's texture type:
     * half-float caps at its 65504 ceiling; float is effectively unbounded (a huge finite +Inf guard);
     * anything else (8-bit LDR, or the default framebuffer when no RT is bound) is [0,1]. Only used when
     * `rawHdrOutput` is enabled.
     * @param textureType the bound render target's texture type (Constants.TEXTURETYPE_*), or undefined
     * @returns the maximum color value that can be stored without overflowing to +Inf
     * @internal
     */
    export function _MaxColorValueForRenderTarget(textureType: number | undefined): number;
    /**
     * This is the sky material which allows to create dynamic and texture free effects for skyboxes.
     * @see https://doc.babylonjs.com/toolsAndResources/assetLibraries/materialsLibrary/skyMat
     */
    export class SkyMaterial extends PushMaterial {
        /**
         * Defines the overall luminance of sky in interval ]0, 1[.
         */
        luminance: number;
        /**
         * Defines the amount (scattering) of haze as opposed to molecules in atmosphere.
         */
        turbidity: number;
        /**
         * Defines the sky appearance (light intensity).
         */
        rayleigh: number;
        /**
         * Defines the mieCoefficient in interval [0, 0.1] which affects the property .mieDirectionalG.
         */
        mieCoefficient: number;
        /**
         * Defines the amount of haze particles following the Mie scattering theory.
         */
        mieDirectionalG: number;
        /**
         * Defines the distance of the sun according to the active scene camera.
         */
        distance: number;
        /**
         * Defines the sun inclination, in interval [-0.5, 0.5]. When the inclination is not 0, the sun is said
         * "inclined".
         */
        inclination: number;
        /**
         * Defines the solar azimuth in interval [0, 1]. The azimuth is the angle in the horizontal plan between
         * an object direction and a reference direction.
         */
        azimuth: number;
        /**
         * Defines the sun position in the sky on (x,y,z). If the property .useSunPosition is set to false, then
         * the property is overridden by the inclination and the azimuth and can be read at any moment.
         */
        sunPosition: Vector3;
        /**
         * Defines if the sun position should be computed (inclination and azimuth) according to the given
         * .sunPosition property.
         */
        useSunPosition: boolean;
        /**
         * Defines an offset vector used to get a horizon offset.
         * @example skyMaterial.cameraOffset.y = camera.globalPosition.y // Set horizon relative to 0 on the Y axis
         */
        cameraOffset: Vector3;
        /**
         * Defines the vector the skyMaterial should consider as up. (default is Vector3(0, 1, 0) as returned by Vector3.Up())
         */
        up: Vector3;
        /**
         * Defines if sky should be dithered.
         */
        dithering: boolean;
        /**
         * When enabled, the material emits scene-referred linear HDR: `luminance` acts as a plain linear
         * gain (no filmic tonemap), the output is clamped to the bound render target's max representable
         * value rather than [0, 1] (so a bright sun cannot overflow to +Inf), and no sRGB encode is
         * applied. Enable this to bake the sky into an HDR (float / half-float) render target — e.g. an
         * IBL environment cube — where the full dynamic range of the sun disc must be preserved. The
         * clamp ceiling follows whatever target is bound at draw time (65504 for half-float, effectively
         * unbounded for float); if the sky is drawn to an LDR target or the default framebuffer it falls
         * back to [0, 1], so this flag is only meaningful when rendering into a float/half-float target.
         * When disabled, the material produces tonemapped, display-referred output for direct viewing.
         */
        rawHdrOutput: boolean;
        /**
         * Cloud cover over the sun in [0, 1] (0 = clear direct sun, default; 1 = sun fully hidden). This
         * softens only the *sun disc* — the sky dome color itself is unchanged (there is no overcast
         * graying or whitening of the sky). At 0 the sun is a sharp solar disc; above 0 a physically-
         * based single-scattering cloud model attenuates the direct beam (Beer–Lambert) and redistributes
         * the removed energy into a dual-lobe Henyey–Greenstein aureole, energy-conserving as it broadens
         * (thin cloud → tight silver lining; heavy cloud → broad, directionless glow). See the sun-disc
         * branch in sky.fragment for the model + references.
         */
        cloudiness: number;
        private _cameraPosition;
        private _skyOrientation;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a new sky material.
         * This material allows to create dynamic and texture free
         * effects for skyboxes by taking care of the atmosphere state.
         * @see https://doc.babylonjs.com/toolsAndResources/assetLibraries/materialsLibrary/skyMat
         * @param name Define the name of the material in the scene
         * @param scene Define the scene the material belong to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        /**
         * Specifies if the material will require alpha blending
         * @returns a boolean specifying if alpha blending is needed
         */
        needAlphaBlending(): boolean;
        /**
         * Specifies if this material should be rendered in alpha test mode
         * @returns false as the sky material doesn't need alpha testing.
         */
        needAlphaTesting(): boolean;
        /**
         * Get the texture used for alpha test purpose.
         * @returns null as the sky material has no texture.
         */
        getAlphaTestTexture(): Nullable<BaseTexture>;
        /**
         * Get if the submesh is ready to be used and all its information available.
         * Child classes can use it to update shaders
         * @param mesh defines the mesh to check
         * @param subMesh defines which submesh to check
         * @returns a boolean indicating that the submesh is ready or not
         */
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh): boolean;
        /**
         * Binds the submesh to this material by preparing the effect and shader to draw
         * @param world defines the world transformation matrix
         * @param mesh defines the mesh containing the submesh
         * @param subMesh defines the submesh to bind the material to
         */
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        /**
         * Get the list of animatables in the material.
         * @returns the list of animatables object used in the material
         */
        getAnimatables(): IAnimatable[];
        /**
         * Disposes the material
         * @param forceDisposeEffect specifies if effects should be forcefully disposed
         */
        dispose(forceDisposeEffect?: boolean): void;
        /**
         * Makes a duplicate of the material, and gives it a new name
         * @param name defines the new name for the duplicated material
         * @returns the cloned material
         */
        clone(name: string): SkyMaterial;
        /**
         * Serializes this material in a JSON representation
         * @returns the serialized material object
         */
        serialize(): any;
        /**
         * Gets the current class name of the material e.g. "SkyMaterial"
         * Mainly use in serialization.
         * @returns the class name
         */
        getClassName(): string;
        /**
         * Creates a sky material from parsed material data
         * @param source defines the JSON representation of the material
         * @param scene defines the hosting scene
         * @param rootUrl defines the root URL to use to load textures and relative dependencies
         * @returns a new sky material
         */
        static Parse(source: any, scene: Scene, rootUrl: string): SkyMaterial;
    }


    /** @internal */
    export var skyVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var skyPixelShader: {
        name: string;
        shader: string;
    };




    /** @internal */
    export var skyVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var skyPixelShaderWGSL: {
        name: string;
        shader: string;
    };


    export class SimpleMaterial extends PushMaterial {
        private _diffuseTexture;
        accessor diffuseTexture: BaseTexture;
        diffuseColor: Color3;
        private _disableLighting;
        accessor disableLighting: boolean;
        private _maxSimultaneousLights;
        accessor maxSimultaneousLights: number;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a Simple Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        getAnimatables(): IAnimatable[];
        getActiveTextures(): BaseTexture[];
        hasTexture(texture: BaseTexture): boolean;
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): SimpleMaterial;
        serialize(): any;
        getClassName(): string;
        static Parse(source: any, scene: Scene, rootUrl: string): SimpleMaterial;
    }


    /** @internal */
    export var simpleVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var simplePixelShader: {
        name: string;
        shader: string;
    };




    /** @internal */
    export var simpleVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var simplePixelShaderWGSL: {
        name: string;
        shader: string;
    };


    /**
     * A transparent "shadow catcher" material: it renders only shadow strength into its alpha channel
     * (over {@link ShadowOnlyMaterial.shadowColor | shadowColor}, black by default), so shadows can be
     * composited over an arbitrary background.
     *
     * It can receive IBL shadows (via `IblShadowsRenderPipeline.addShadowReceivingMaterial` /
     * the Frame Graph IBL shadows task). Because the material has a single alpha output channel, IBL
     * shadows are received as **monochrome**: a colored IBL shadow is reduced to its luminance rather
     * than preserving per-channel hue.
     */
    export class ShadowOnlyMaterial extends PushMaterial {
        private _activeLight;
        private _needAlphaBlending;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a ShadowOnly Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        /**
         * @internal
         * Force the material uniform buffer into "no UBO" (individual uniform) mode so that any attached
         * material plugin (e.g. IBLShadowsPluginMaterial) binds its uniforms directly on the effect. This
         * lets ShadowOnlyMaterial host plugins without declaring a dedicated "Material" uniform block in its
         * shaders (its own uniforms - alpha/shadowColor/... - stay individual uniforms). The base class only
         * does this on WebGPU ("leftovers UBO"); we extend it to every backend.
         */
        _createUniformBuffer(): void;
        /**
         * The color the shadow is rendered with (black by default). Only its RGB is used; shadow
         * strength is written to the material's alpha channel.
         */
        shadowColor: Color3;
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        get activeLight(): IShadowLight;
        set activeLight(light: IShadowLight);
        private _getFirstShadowLightForMesh;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        clone(name: string): ShadowOnlyMaterial;
        serialize(): any;
        getClassName(): string;
        /**
         * Creates a ShadowOnly material from parsed material data.
         * @param source defines the JSON representation of the material
         * @param scene defines the hosting scene
         * @param rootUrl defines the root URL to use to load textures and relative dependencies
         * @returns a new ShadowOnly material
         */
        static Parse(source: any, scene: Scene, rootUrl: string): ShadowOnlyMaterial;
    }


    /** @internal */
    export var shadowOnlyVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var shadowOnlyPixelShader: {
        name: string;
        shader: string;
    };




    /** @internal */
    export var shadowOnlyVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var shadowOnlyPixelShaderWGSL: {
        name: string;
        shader: string;
    };


    export class NormalMaterial extends PushMaterial {
        private _diffuseTexture;
        accessor diffuseTexture: BaseTexture;
        diffuseColor: Color3;
        private _disableLighting;
        accessor disableLighting: boolean;
        private _maxSimultaneousLights;
        accessor maxSimultaneousLights: number;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a Normal Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        needAlphaBlending(): boolean;
        needAlphaBlendingForMesh(mesh: AbstractMesh): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        getAnimatables(): IAnimatable[];
        getActiveTextures(): BaseTexture[];
        hasTexture(texture: BaseTexture): boolean;
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): NormalMaterial;
        serialize(): any;
        getClassName(): string;
        static Parse(source: any, scene: Scene, rootUrl: string): NormalMaterial;
    }


    /** @internal */
    export var normalVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var normalPixelShader: {
        name: string;
        shader: string;
    };




    /** @internal */
    export var normalVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var normalPixelShaderWGSL: {
        name: string;
        shader: string;
    };


    export class MixMaterial extends PushMaterial {
        /**
         * Mix textures
         */
        private _mixTexture1;
        accessor mixTexture1: BaseTexture;
        private _mixTexture2;
        accessor mixTexture2: BaseTexture;
        /**
         * Diffuse textures
         */
        private _diffuseTexture1;
        accessor diffuseTexture1: Texture;
        private _diffuseTexture2;
        accessor diffuseTexture2: Texture;
        private _diffuseTexture3;
        accessor diffuseTexture3: Texture;
        private _diffuseTexture4;
        accessor diffuseTexture4: Texture;
        private _diffuseTexture5;
        accessor diffuseTexture5: Texture;
        private _diffuseTexture6;
        accessor diffuseTexture6: Texture;
        private _diffuseTexture7;
        accessor diffuseTexture7: Texture;
        private _diffuseTexture8;
        accessor diffuseTexture8: Texture;
        /**
         * Uniforms
         */
        diffuseColor: Color3;
        specularColor: Color3;
        specularPower: number;
        private _disableLighting;
        accessor disableLighting: boolean;
        private _maxSimultaneousLights;
        accessor maxSimultaneousLights: number;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a Mix Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        getAnimatables(): IAnimatable[];
        getActiveTextures(): BaseTexture[];
        hasTexture(texture: BaseTexture): boolean;
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): MixMaterial;
        serialize(): any;
        getClassName(): string;
        static Parse(source: any, scene: Scene, rootUrl: string): MixMaterial;
    }


    /** @internal */
    export var mixVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var mixPixelShader: {
        name: string;
        shader: string;
    };




    /** @internal */
    export var mixVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var mixPixelShaderWGSL: {
        name: string;
        shader: string;
    };
































    export class LavaMaterial extends PushMaterial {
        private _diffuseTexture;
        accessor diffuseTexture: BaseTexture;
        noiseTexture: BaseTexture;
        fogColor: Color3;
        speed: number;
        movingSpeed: number;
        lowFrequencySpeed: number;
        fogDensity: number;
        private _lastTime;
        diffuseColor: Color3;
        private _disableLighting;
        accessor disableLighting: boolean;
        private _unlit;
        accessor unlit: boolean;
        private _maxSimultaneousLights;
        accessor maxSimultaneousLights: number;
        private _scaledDiffuse;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a Lava Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        getAnimatables(): IAnimatable[];
        getActiveTextures(): BaseTexture[];
        hasTexture(texture: BaseTexture): boolean;
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): LavaMaterial;
        serialize(): any;
        getClassName(): string;
        static Parse(source: any, scene: Scene, rootUrl: string): LavaMaterial;
    }


    /** @internal */
    export var lavaVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var lavaPixelShader: {
        name: string;
        shader: string;
    };




    /** @internal */
    export var lavaVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var lavaPixelShaderWGSL: {
        name: string;
        shader: string;
    };




    /**
     * The grid materials allows you to wrap any shape with a grid.
     * Colors are customizable.
     */
    export class GridMaterial extends PushMaterial {
        /**
         * Main color of the grid (e.g. between lines)
         */
        mainColor: Color3;
        /**
         * Color of the grid lines.
         */
        lineColor: Color3;
        /**
         * The scale of the grid compared to unit.
         */
        gridRatio: number;
        /**
         * Allows setting an offset for the grid lines.
         */
        gridOffset: Vector3;
        /**
         * The frequency of thicker lines.
         */
        majorUnitFrequency: number;
        /**
         * The visibility of minor units in the grid.
         */
        minorUnitVisibility: number;
        /**
         * Overall mesh opacity. In linesOnly mode this also scales the maximum line alpha.
         */
        opacity: number;
        /**
         * Whether to antialias the grid
         */
        antialias: boolean;
        /**
         * Color of grid lines when the camera is below the surface.
         * When set, lineColor acts as the above-surface color.
         */
        get belowLineColor(): Nullable<Color3>;
        set belowLineColor(value: Nullable<Color3>);
        private _belowLineColor;
        /**
         * Enable multi-scale logarithmic grid LOD. Number of octaves is controlled by gridOctaves.
         */
        useMultiScale: boolean;
        /**
         * World-unit spacing of the finest octave. Default 0.001.
         */
        minGridSpacing: number;
        /**
         * Number of logarithmic octaves rendered (1–8). Default 4.
         */
        gridOctaves: number;
        /**
         * Enable camera-distance-aware horizon (grazing-angle) fade.
         */
        useHorizonFade: boolean;
        /**
         * Render an ultra-fine crosshair at the world origin.
         */
        useOriginMarker: boolean;
        /**
         * When true, only grid lines are visible — non-grid pixels are discarded.
         * Puts the material in the alpha-blend queue and enables a depth pre-pass so grid lines
         * correctly occlude translucent objects (e.g. Gaussian splats). Set mesh.alphaIndex to a
         * value lower than other transparent objects so the depth pre-pass fires first.
         */
        get linesOnly(): boolean;
        set linesOnly(value: boolean);
        private _linesOnly;
        /**
         * Scales grid line width. Values \> 1 produce thicker lines. Default 1.0.
         */
        gridThicknessModifier: number;
        /**
         * Determine RBG output is premultiplied by alpha value.
         */
        preMultiplyAlpha: boolean;
        /**
         * Determines if the max line value will be used instead of the sum wherever grid lines intersect.
         */
        useMaxLine: boolean;
        private _opacityTexture;
        /**
         * Texture to define opacity of the grid
         */
        accessor opacityTexture: BaseTexture;
        private _gridControl;
        private _viewportSize;
        /**
         * constructor
         * @param name The name given to the material in order to identify it afterwards.
         * @param scene The scene the material is used in.
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        private static readonly _ShaderLoader;
        /**
         * @returns whether or not the grid requires alpha blending.
         */
        needAlphaBlending(): boolean;
        needAlphaBlendingForMesh(mesh: AbstractMesh): boolean;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        /**
         * Dispose the material and its associated resources.
         * @param forceDisposeEffect will also dispose the used effect when true
         */
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): GridMaterial;
        serialize(): any;
        getClassName(): string;
        /**
         * Parse a JSON input to create back a grid material.
         * @param source the JSON data to parse
         * @param scene defines the hosting scene
         * @param rootUrl defines the root URL to use to load textures and relative dependencies
         * @returns a new grid material
         */
        static Parse(source: any, scene: Scene, rootUrl: string): GridMaterial;
    }


    /** @internal */
    export var gridVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var gridPixelShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var gridVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var gridPixelShaderWGSL: {
        name: string;
        shader: string;
    };




    export class GradientMaterial extends PushMaterial {
        private _maxSimultaneousLights;
        accessor maxSimultaneousLights: number;
        topColor: Color3;
        topColorAlpha: number;
        bottomColor: Color3;
        bottomColorAlpha: number;
        offset: number;
        scale: number;
        smoothness: number;
        private _disableLighting;
        accessor disableLighting: boolean;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a Gradient Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        getAnimatables(): IAnimatable[];
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): GradientMaterial;
        serialize(): any;
        getClassName(): string;
        static Parse(source: any, scene: Scene, rootUrl: string): GradientMaterial;
    }


    /** @internal */
    export var gradientVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var gradientPixelShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var gradientVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var gradientPixelShaderWGSL: {
        name: string;
        shader: string;
    };




    export class FurMaterial extends PushMaterial {
        private _diffuseTexture;
        accessor diffuseTexture: BaseTexture;
        private _heightTexture;
        accessor heightTexture: BaseTexture;
        diffuseColor: Color3;
        furLength: number;
        furAngle: number;
        furColor: Color3;
        furOffset: number;
        furSpacing: number;
        furGravity: Vector3;
        furSpeed: number;
        furDensity: number;
        furOcclusion: number;
        furTexture: DynamicTexture;
        private _disableLighting;
        accessor disableLighting: boolean;
        private _maxSimultaneousLights;
        accessor maxSimultaneousLights: number;
        highLevelFur: boolean;
        _meshes: AbstractMesh[];
        private _furTime;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a Fur Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        get furTime(): number;
        set furTime(furTime: number);
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        updateFur(): void;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        getAnimatables(): IAnimatable[];
        getActiveTextures(): BaseTexture[];
        hasTexture(texture: BaseTexture): boolean;
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): FurMaterial;
        serialize(): any;
        getClassName(): string;
        static Parse(source: any, scene: Scene, rootUrl: string): FurMaterial;
        static GenerateTexture(name: string, scene: Scene): DynamicTexture;
        static FurifyMesh(sourceMesh: Mesh, quality: number): Mesh[];
    }


    /** @internal */
    export var furVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var furPixelShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var furVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var furPixelShaderWGSL: {
        name: string;
        shader: string;
    };




    export class FireMaterial extends PushMaterial {
        private _diffuseTexture;
        accessor diffuseTexture: Nullable<BaseTexture>;
        private _distortionTexture;
        accessor distortionTexture: Nullable<BaseTexture>;
        private _opacityTexture;
        accessor opacityTexture: Nullable<BaseTexture>;
        diffuseColor: Color3;
        speed: number;
        private _scaledDiffuse;
        private _lastTime;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a Fire Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        getAnimatables(): IAnimatable[];
        getActiveTextures(): BaseTexture[];
        hasTexture(texture: BaseTexture): boolean;
        getClassName(): string;
        dispose(forceDisposeEffect?: boolean): void;
        clone(name: string): FireMaterial;
        serialize(): any;
        static Parse(source: any, scene: Scene, rootUrl: string): FireMaterial;
    }


    /** @internal */
    export var fireVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var firePixelShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var fireVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var firePixelShaderWGSL: {
        name: string;
        shader: string;
    };


    /**
     * Albedo parts of the shader
     */
    export class ShaderAlbedoParts {
        constructor();
        /**
         * Beginning of the fragment shader
         */
        Fragment_Begin: string;
        /**
         * Fragment definitions
         */
        Fragment_Definitions: string;
        /**
         * Beginning of the main function
         */
        Fragment_MainBegin: string;
        /**
         * End of main function
         */
        Fragment_MainEnd: string;
        /**
         * Albedo color
         */
        Fragment_Custom_Albedo: string;
        /**
         * Lights
         */
        Fragment_Before_Lights: string;
        /**
         * Metallic and roughness
         */
        Fragment_Custom_MetallicRoughness: string;
        /**
         * Microsurface
         */
        Fragment_Custom_MicroSurface: string;
        /**
         * Fog computations
         */
        Fragment_Before_Fog: string;
        /**
         * Alpha
         */
        Fragment_Custom_Alpha: string;
        /**
         * Color composition
         */
        Fragment_Before_FinalColorComposition: string;
        /**
         * Fragment color
         */
        Fragment_Before_FragColor: string;
        /**
         * Beginning of vertex shader
         */
        Vertex_Begin: string;
        /**
         * Vertex definitions
         */
        Vertex_Definitions: string;
        /**
         * Vertex main begin
         */
        Vertex_MainBegin: string;
        /**
         * Vertex before position updated
         */
        Vertex_Before_PositionUpdated: string;
        /**
         * Vertex before normal updated
         */
        Vertex_Before_NormalUpdated: string;
        /**
         * Vertex after world pos computed
         */
        Vertex_After_WorldPosComputed: string;
        /**
         * Vertex main end
         */
        Vertex_MainEnd: string;
    }
    /**
     * @deprecated use ShaderAlbedoParts instead.
     */
    export var ShaderAlebdoParts: typeof ShaderAlbedoParts;
    export class PBRCustomMaterial extends PBRMaterial {
        /**
         * Index for each created shader
         */
        static ShaderIndexer: number;
        /**
         * Custom shader structure
         */
        CustomParts: ShaderAlbedoParts;
        /**
         * Name of the shader
         */
        _createdShaderName: string;
        /**
         * List of custom uniforms
         */
        _customUniform: string[];
        /**
         * Names of the new uniforms
         */
        _newUniforms: string[];
        /**
         * Instances of the new uniform objects
         */
        _newUniformInstances: {
            [name: string]: any;
        };
        /**
         * Instances of the new sampler objects
         */
        _newSamplerInstances: {
            [name: string]: Texture;
        };
        /**
         * List of the custom attributes
         */
        _customAttributes: string[];
        private readonly _customEffects;
        /**
         * Fragment shader string
         */
        FragmentShader: string;
        /**
         * Vertex shader string
         */
        VertexShader: string;
        /**
         * Runs after the material is bound to a mesh
         * @param mesh mesh bound
         * @param effect bound effect used to render
         */
        AttachAfterBind(mesh: Mesh | undefined, effect: Effect): void;
        /**
         * @internal
         */
        ReviewUniform(name: string, arr: string[]): string[];
        /**
         * Builds the material
         * @param shaderName name of the shader
         * @param uniforms list of uniforms
         * @param uniformBuffers list of uniform buffers
         * @param samplers list of samplers
         * @param defines list of defines
         * @param attributes list of attributes
         * @param options options to compile the shader
         * @returns the shader name
         */
        Builder(shaderName: string, uniforms: string[], uniformBuffers: string[], samplers: string[], defines: MaterialDefines | string[], attributes?: string[], options?: ICustomShaderNameResolveOptions): string;
        protected _injectCustomCode(code: string, shaderType: string): string;
        protected _getCustomCode(shaderType: string): {
            [pointName: string]: string;
        };
        constructor(name: string, scene?: Scene);
        private _isCreatedShaderEffect;
        /**
         * Disposes the material
         * @param forceDisposeEffect specifies if effects should be forcefully disposed
         * @param forceDisposeTextures specifies if textures should be forcefully disposed
         */
        dispose(forceDisposeEffect?: boolean, forceDisposeTextures?: boolean): void;
        protected _afterBind(mesh?: Mesh, effect?: Nullable<Effect>, subMesh?: SubMesh): void;
        /**
         * Adds a new uniform to the shader
         * @param name the name of the uniform to add
         * @param kind the type of the uniform to add
         * @param param the value of the uniform to add
         * @returns the current material
         */
        AddUniform(name: string, kind: string, param: any): PBRCustomMaterial;
        /**
         * Adds a custom attribute
         * @param name the name of the attribute
         * @returns the current material
         */
        AddAttribute(name: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_Begin portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Begin(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_Definitions portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Definitions(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_MainBegin portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_MainBegin(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_Custom_Albedo portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Custom_Albedo(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_Custom_Alpha portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Custom_Alpha(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_Before_Lights portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Before_Lights(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_Custom_MetallicRoughness portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Custom_MetallicRoughness(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_Custom_MicroSurface portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Custom_MicroSurface(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_Before_Fog portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Before_Fog(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_Before_FinalColorComposition portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Before_FinalColorComposition(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_Before_FragColor portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Before_FragColor(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Fragment_MainEnd portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_MainEnd(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Vertex_Begin portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_Begin(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Vertex_Definitions portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_Definitions(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Vertex_MainBegin portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_MainBegin(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Vertex_Before_PositionUpdated portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_Before_PositionUpdated(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Vertex_Before_NormalUpdated portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_Before_NormalUpdated(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Vertex_After_WorldPosComputed portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_After_WorldPosComputed(shaderPart: string): PBRCustomMaterial;
        /**
         * Sets the code on Vertex_MainEnd portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_MainEnd(shaderPart: string): PBRCustomMaterial;
    }




    /**
     * Structure of a custom shader
     */
    export class CustomShaderStructure {
        /**
         * Fragment store
         */
        FragmentStore: string;
        /**
         * Vertex store
         */
        VertexStore: string;
        constructor();
    }
    /**
     * Parts of a shader
     */
    export class ShaderSpecialParts {
        constructor();
        /**
         * Beginning of the fragment shader
         */
        Fragment_Begin: string;
        /**
         * Variable definitions of the fragment shader
         */
        Fragment_Definitions: string;
        /**
         * Beginning of the fragment main function
         */
        Fragment_MainBegin: string;
        /**
         * End of the fragment main function
         */
        Fragment_MainEnd: string;
        /**
         * Diffuse color calculation
         */
        Fragment_Custom_Diffuse: string;
        /**
         * Before lightning computations
         */
        Fragment_Before_Lights: string;
        /**
         * Before fog computations
         */
        Fragment_Before_Fog: string;
        /**
         * Alpha calculations
         */
        Fragment_Custom_Alpha: string;
        /**
         * Before frag color is assigned
         */
        Fragment_Before_FragColor: string;
        /**
         * Beginning of the vertex shader
         */
        Vertex_Begin: string;
        /**
         * Variable definitions of the vertex shader
         */
        Vertex_Definitions: string;
        /**
         * Start of the main function of the vertex shader
         */
        Vertex_MainBegin: string;
        /**
         * Before the world position computation
         */
        Vertex_Before_PositionUpdated: string;
        /**
         * Before the normal computation
         */
        Vertex_Before_NormalUpdated: string;
        /**
         * After the world position has been computed
         */
        Vertex_After_WorldPosComputed: string;
        /**
         * Main end of the vertex shader
         */
        Vertex_MainEnd: string;
    }
    /**
     * Customized material
     */
    export class CustomMaterial extends StandardMaterial {
        /**
         * Index for each created shader
         */
        static ShaderIndexer: number;
        /**
         * Custom shader structure
         */
        CustomParts: ShaderSpecialParts;
        /**
         * Name of the shader
         */
        _createdShaderName: string;
        /**
         * List of custom uniforms
         */
        _customUniform: string[];
        /**
         * Names of the new uniforms
         */
        _newUniforms: string[];
        /**
         * Instances of the new uniform objects
         */
        _newUniformInstances: {
            [name: string]: any;
        };
        /**
         * Instances of the new sampler objects
         */
        _newSamplerInstances: {
            [name: string]: Texture;
        };
        /**
         * List of the custom attributes
         */
        _customAttributes: string[];
        /**
         * Fragment shader string
         */
        FragmentShader: string;
        /**
         * Vertex shader string
         */
        VertexShader: string;
        /**
         * Runs after the material is bound to a mesh
         * @param mesh mesh bound
         * @param effect bound effect used to render
         */
        AttachAfterBind(mesh: Mesh | undefined, effect: Effect): void;
        /**
         * @internal
         */
        ReviewUniform(name: string, arr: string[]): string[];
        /**
         * Builds the material
         * @param shaderName name of the shader
         * @param uniforms list of uniforms
         * @param uniformBuffers list of uniform buffers
         * @param samplers list of samplers
         * @param defines list of defines
         * @param attributes list of attributes
         * @returns the shader name
         */
        Builder(shaderName: string, uniforms: string[], uniformBuffers: string[], samplers: string[], defines: MaterialDefines | string[], attributes?: string[]): string;
        protected _injectCustomCode(code: string, shaderType: string): string;
        protected _getCustomCode(shaderType: string): {
            [pointName: string]: string;
        };
        constructor(name: string, scene?: Scene);
        protected _afterBind(mesh?: Mesh, effect?: Nullable<Effect>, subMesh?: SubMesh): void;
        /**
         * Adds a new uniform to the shader
         * @param name the name of the uniform to add
         * @param kind the type of the uniform to add
         * @param param the value of the uniform to add
         * @returns the current material
         */
        AddUniform(name: string, kind: string, param: any): CustomMaterial;
        /**
         * Adds a custom attribute
         * @param name the name of the attribute
         * @returns the current material
         */
        AddAttribute(name: string): CustomMaterial;
        /**
         * Sets the code on Fragment_Begin portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Begin(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Fragment_Definitions portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Definitions(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Fragment_MainBegin portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_MainBegin(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Fragment_MainEnd portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_MainEnd(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Fragment_Custom_Diffuse portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Custom_Diffuse(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Fragment_Custom_Alpha portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Custom_Alpha(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Fragment_Before_Lights portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Before_Lights(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Fragment_Before_Fog portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Before_Fog(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Fragment_Before_FragColor portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Fragment_Before_FragColor(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Vertex_Begin portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_Begin(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Vertex_Definitions portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_Definitions(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Vertex_MainBegin portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_MainBegin(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Vertex_Before_PositionUpdated portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_Before_PositionUpdated(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Vertex_Before_NormalUpdated portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_Before_NormalUpdated(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Vertex_After_WorldPosComputed portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_After_WorldPosComputed(shaderPart: string): CustomMaterial;
        /**
         * Sets the code on Vertex_MainEnd portion
         * @param shaderPart the code string
         * @returns the current material
         */
        Vertex_MainEnd(shaderPart: string): CustomMaterial;
    }




    export class CellMaterial extends PushMaterial {
        private _diffuseTexture;
        accessor diffuseTexture: BaseTexture;
        diffuseColor: Color3;
        _computeHighLevel: boolean;
        accessor computeHighLevel: boolean;
        private _disableLighting;
        accessor disableLighting: boolean;
        private _maxSimultaneousLights;
        accessor maxSimultaneousLights: number;
        private static readonly _ShaderLoader;
        /**
         * Instantiates a Cell Material in the given scene
         * @param name The friendly name of the material
         * @param scene The scene to add the material to
         * @param forceGLSL Use the GLSL code generation for the shader (even on WebGPU). Default is false
         */
        constructor(name: string, scene?: Scene, forceGLSL?: boolean);
        needAlphaBlending(): boolean;
        needAlphaTesting(): boolean;
        getAlphaTestTexture(): Nullable<BaseTexture>;
        isReadyForSubMesh(mesh: AbstractMesh, subMesh: SubMesh, useInstances?: boolean): boolean;
        bindForSubMesh(world: Matrix, mesh: Mesh, subMesh: SubMesh): void;
        getAnimatables(): IAnimatable[];
        getActiveTextures(): BaseTexture[];
        hasTexture(texture: BaseTexture): boolean;
        dispose(forceDisposeEffect?: boolean): void;
        getClassName(): string;
        clone(name: string): CellMaterial;
        serialize(): any;
        static Parse(source: any, scene: Scene, rootUrl: string): CellMaterial;
    }


    /** @internal */
    export var cellVertexShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var cellPixelShader: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var cellVertexShaderWGSL: {
        name: string;
        shader: string;
    };


    /** @internal */
    export var cellPixelShaderWGSL: {
        name: string;
        shader: string;
    };



}


                