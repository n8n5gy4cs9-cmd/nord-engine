
declare namespace BABYLON {








    /**
     * The Edge Detection effect highlights the edges of objects in the scene like a toon.
     * This can be used for stylized rendering, outlining, or visual effects that require edge enhancement.
     */
    export class EdgeDetectionPostProcess extends PostProcess {
        /**
         * Defines the color of the detected edges.
         */
        edgeColor: Color3;
        /**
         * Defines the intensity of the detected edges.
         * Higher values result in more pronounced edges.
         * default: 0.2  (min:0, max:1)
         */
        edgeIntensity: number;
        /**
         * Defines the width of the detected edges.
         * Higher values result in thicker edges.
         * default: 0.2 (min:0.125, max:1)
         */
        edgeWidth: number;
        /**
         * Defines the render mode.
         * default: 0
         * 0: general, 1: normal, 2: depth, 3: outline only
         */
        renderMode: number;
        private _geometryBufferRenderer;
        /**
         * Get the current class name of the current effect
         * @returns "EdgeDetectionPostProcess"
         */
        getClassName(): string;
        /**
         * Creates a new instance of EdgeDetectionPostProcess.
         * @param name The name of the effect.
         * @param scene The scene where the edge detection post-process will be applied.
         * @param options The required width/height ratio or specific options for the post-process.
         * @param camera The camera to apply the post-process to.
         * @param samplingMode The sampling mode to be used when computing the pass. (default: TEXTURE_NEAREST_NEAREST)
         * @param reusable If the post-process can be reused on the same frame. (default: false)
         * @param textureType The type of textures used when performing the post-process. (default: TEXTURETYPE_HALF_FLOAT)
         */
        constructor(name: string, scene: Scene, options: number | PostProcessOptions, camera: Nullable<Camera>, samplingMode?: number, reusable?: boolean, textureType?: number);
        /**
         * Support test.
         */
        static get IsSupported(): boolean;
        /**
         * @internal
         */
        static _Parse(parsedPostProcess: any, targetCamera: Camera, scene: Scene, rootUrl: string): EdgeDetectionPostProcess;
    }


    /** @internal */
    export var edgeDetectionPixelShader: {
        name: string;
        shader: string;
    };




    /** @internal */
    export var digitalrainPixelShader: {
        name: string;
        shader: string;
    };


    /**
     * DigitalRainFontTexture is the helper class used to easily create your digital rain font texture.
     *
     * It basically takes care rendering the font front the given font size to a texture.
     * This is used later on in the postprocess.
     */
    export class DigitalRainFontTexture extends BaseTexture {
        private _font;
        private _text;
        private _charSize;
        /**
         * Gets the size of one char in the texture (each char fits in size * size space in the texture).
         */
        get charSize(): number;
        /**
         * Create a new instance of the Digital Rain FontTexture class
         * @param name the name of the texture
         * @param font the font to use, use the W3C CSS notation
         * @param text the caracter set to use in the rendering.
         * @param scene the scene that owns the texture
         */
        constructor(name: string, font: string, text: string, scene?: Nullable<Scene>);
        /**
         * Gets the max char width of a font.
         * @param font the font to use, use the W3C CSS notation
         * @returns the max char width
         */
        private _getFontWidth;
        /**
         * Gets the max char height of a font.
         * @param font the font to use, use the W3C CSS notation
         * @returns the max char height
         */
        private _getFontHeight;
        /**
         * Clones the current DigitalRainFontTexture.
         * @returns the clone of the texture.
         */
        clone(): DigitalRainFontTexture;
        /**
         * Parses a json object representing the texture and returns an instance of it.
         * @param source the source JSON representation
         * @param scene the scene to create the texture for
         * @returns the parsed texture
         */
        static Parse(source: any, scene: Scene): DigitalRainFontTexture;
    }
    /**
     * Option available in the Digital Rain Post Process.
     */
    export interface IDigitalRainPostProcessOptions {
        /**
         * The font to use following the w3c font definition.
         */
        font?: string;
        /**
         * This defines the amount you want to mix the "tile" or caracter space colored in the digital rain.
         * This number is defined between 0 and 1;
         */
        mixToTile?: number;
        /**
         * This defines the amount you want to mix the normal rendering pass in the digital rain.
         * This number is defined between 0 and 1;
         */
        mixToNormal?: number;
    }
    /**
     * DigitalRainPostProcess helps rendering everithing in digital rain.
     *
     * Simmply add it to your scene and let the nerd that lives in you have fun.
     * Example usage: var pp = new DigitalRainPostProcess("digitalRain", "20px Monospace", camera);
     */
    export class DigitalRainPostProcess extends PostProcess {
        /**
         * The font texture used to render the char in the post process.
         */
        private _digitalRainFontTexture;
        /**
         * This defines the amount you want to mix the "tile" or caracter space colored in the digital rain.
         * This number is defined between 0 and 1;
         */
        mixToTile: number;
        /**
         * This defines the amount you want to mix the normal rendering pass in the digital rain.
         * This number is defined between 0 and 1;
         */
        mixToNormal: number;
        /**
         * Speed of the effect
         */
        speed: number;
        /**
         * Instantiates a new Digital Rain Post Process.
         * @param name the name to give to the postprocess
         * @camera the camera to apply the post process to.
         * @param camera
         * @param options can either be the font name or an option object following the IDigitalRainPostProcessOptions format
         */
        constructor(name: string, camera: Nullable<Camera>, options?: string | IDigitalRainPostProcessOptions);
    }




    /** @internal */
    export var asciiartPixelShader: {
        name: string;
        shader: string;
    };


    /**
     * AsciiArtFontTexture is the helper class used to easily create your ascii art font texture.
     *
     * It basically takes care rendering the font front the given font size to a texture.
     * This is used later on in the postprocess.
     */
    export class AsciiArtFontTexture extends BaseTexture {
        private _font;
        private _text;
        private _charSize;
        /**
         * Gets the size of one char in the texture (each char fits in size * size space in the texture).
         */
        get charSize(): number;
        /**
         * Create a new instance of the Ascii Art FontTexture class
         * @param name the name of the texture
         * @param font the font to use, use the W3C CSS notation
         * @param text the caracter set to use in the rendering.
         * @param scene the scene that owns the texture
         */
        constructor(name: string, font: string, text: string, scene?: Nullable<Scene>);
        /**
         * Gets the max char width of a font.
         * @param font the font to use, use the W3C CSS notation
         * @returns the max char width
         */
        private _getFontWidth;
        /**
         * Gets the max char height of a font.
         * @param font the font to use, use the W3C CSS notation
         * @returns the max char height
         */
        private _getFontHeight;
        /**
         * Clones the current AsciiArtTexture.
         * @returns the clone of the texture.
         */
        clone(): AsciiArtFontTexture;
        /**
         * Parses a json object representing the texture and returns an instance of it.
         * @param source the source JSON representation
         * @param scene the scene to create the texture for
         * @returns the parsed texture
         */
        static Parse(source: any, scene: Scene): AsciiArtFontTexture;
    }
    /**
     * Option available in the Ascii Art Post Process.
     */
    export interface IAsciiArtPostProcessOptions {
        /**
         * The font to use following the w3c font definition.
         */
        font?: string;
        /**
         * The character set to use in the postprocess.
         */
        characterSet?: string;
        /**
         * This defines the amount you want to mix the "tile" or caracter space colored in the ascii art.
         * This number is defined between 0 and 1;
         */
        mixToTile?: number;
        /**
         * This defines the amount you want to mix the normal rendering pass in the ascii art.
         * This number is defined between 0 and 1;
         */
        mixToNormal?: number;
    }
    /**
     * AsciiArtPostProcess helps rendering everithing in Ascii Art.
     *
     * Simmply add it to your scene and let the nerd that lives in you have fun.
     * Example usage: var pp = new AsciiArtPostProcess("myAscii", "20px Monospace", camera);
     */
    export class AsciiArtPostProcess extends PostProcess {
        /**
         * The font texture used to render the char in the post process.
         */
        private _asciiArtFontTexture;
        /**
         * This defines the amount you want to mix the "tile" or caracter space colored in the ascii art.
         * This number is defined between 0 and 1;
         */
        mixToTile: number;
        /**
         * This defines the amount you want to mix the normal rendering pass in the ascii art.
         * This number is defined between 0 and 1;
         */
        mixToNormal: number;
        /**
         * Instantiates a new Ascii Art Post Process.
         * @param name the name to give to the postprocess
         * @camera the camera to apply the post process to.
         * @param camera
         * @param options can either be the font name or an option object following the IAsciiArtPostProcessOptions format
         */
        constructor(name: string, camera: Nullable<Camera>, options?: string | IAsciiArtPostProcessOptions);
    }



}


                