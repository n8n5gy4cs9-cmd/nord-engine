import { createDesk } from './desk.js';
export async function createRiver(canvas, articles, open) {
  const d = await createDesk(canvas),
    { B, scene } = d;
  const papers = [],
    bodies = [];
  let time = 0;
  const wrapText = (ctx, text, x, y, width, lineHeight, max = 4) => {
    let line = '',
      n = 0;
    for (const word of text.split(/\s+/)) {
      if (ctx.measureText(line + word).width > width && line) {
        ctx.fillText(line, x, y + n * lineHeight);
        if (++n >= max) return;
        line = '';
      }
      line += word + ' ';
    }
    if (n < max) ctx.fillText(line, x, y + n * lineHeight);
  };
  articles.slice(0, 18).forEach((a, i) => {
    const width = a.star ? 4.5 : 3.6,
      height = a.star ? 3.2 : 2.5,
      p = d.paper('Article ' + i, width, height, (ctx) => {
        ctx.fillStyle = a.star ? '#fff2c9' : '#f7f4e9';
        ctx.fillRect(0, 0, 1024, 768);
        ctx.fillStyle = '#298a86';
        ctx.fillRect(58, 60, 72, 8);
        ctx.font = '22px system-ui';
        ctx.fillText(a.source.toUpperCase().slice(0, 45), 58, 112);
        ctx.fillStyle = '#1e3548';
        ctx.font = 'bold 48px system-ui';
        wrapText(ctx, a.title, 58, 205, 900, 60, 4);
        ctx.fillStyle = '#5f737b';
        ctx.font = '27px system-ui';
        wrapText(ctx, a.summary, 58, 500, 890, 36, 5);
        ctx.font = '22px system-ui';
        ctx.fillText(
          a.star ? 'STARRED · FLOATING HIGHER' : a.read ? 'READ' : 'UNREAD',
          58,
          728,
        );
      });
    p.mesh.position.set(((i % 3) - 1) * 5, a.star ? 2 : 1, Math.floor(i / 3) * 4.6 - 12);
    p.mesh.rotation.z = i % 2 ? 0.035 : -0.035;
    p.mesh.metadata = { article: a.id };
    papers.push({ ...p, article: a, width, height, phase: i, dropped: false });
  });
  scene.onPointerObservable.add((info) => {
    if (info.type === B.PointerEventTypes.POINTERPICK) {
      const id = info.pickInfo?.pickedMesh?.metadata?.article;
      if (id) open(id);
    }
  });
  d.update.add((dt) => {
    time += dt;
    for (const p of papers)
      if (!p.dropped) {
        p.mesh.position.z += dt * 0.65;
        if (p.mesh.position.z > 15) p.mesh.position.z = -14;
        p.mesh.position.y =
          (p.article.star ? 2 : 1) + Math.sin(time * 0.7 + p.phase) * 0.15;
        p.mesh.rotation.z = Math.sin(time * 0.35 + p.phase) * 0.035;
      }
  });
  return {
    ...d,
    papers,
    flick(id) {
      const p = papers.find((p) => p.article.id === id);
      if (!p || p.dropped) return;
      p.dropped = true;
      const body = B.MeshBuilder.CreateBox(
        'Paper collider',
        { width: p.width, height: 0.05, depth: p.height },
        scene,
      );
      body.position.copyFrom(p.mesh.position);
      body.visibility = 0;
      p.mesh.parent = body;
      p.mesh.position.set(0, 0, 0);
      const aggregate = new B.PhysicsAggregate(
        body,
        B.PhysicsShapeType.BOX,
        { mass: 0.2, restitution: 0.5, friction: 0.5 },
        scene,
      );
      aggregate.body.applyImpulse(new B.Vector3(1.6, 2.8, -1.2), body.position);
      bodies.push(aggregate);
    },
    dispose() {
      bodies.forEach((v) => v.dispose());
      d.dispose();
    },
  };
}
