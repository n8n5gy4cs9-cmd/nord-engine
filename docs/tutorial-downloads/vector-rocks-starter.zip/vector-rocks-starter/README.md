# Vector Rocks starter

All art, sound, prefabs and scenes are ready; the game scripts are not. Write them following the tutorial page and attach each one to the object the page names.
