// Scene: entity tree, lifecycle (init → start → update/fixedUpdate/lateUpdate), loading, prefabs.
import { Entity } from './entity.js';
import { Scheduler } from './util.js';
import { resolveAttributes } from './script.js';
import { prepareScript, sceneHooks } from './unity-lifecycle.js';

export const FIXED_DT = 1 / 60;
const MAX_STEPS = 5;

const rid = () => Math.random().toString(36).slice(2, 10).padEnd(8, '0');

/** Deep-merge prefab overrides onto entity data. Plain objects merge; objects with numeric keys patch arrays by index. */
export function applyOverrides(target, ov) {
  if (ov == null || typeof ov !== 'object') return ov;
  if (Array.isArray(target) && !Array.isArray(ov) && Object.keys(ov).every((k) => /^\d+$/.test(k))) {
    for (const [i, v] of Object.entries(ov)) target[i] = typeof v === 'object' && v !== null && !Array.isArray(v) ? applyOverrides(target[i] ?? {}, v) : v;
    return target;
  }
  if (Array.isArray(ov)) return structuredClone(ov);
  for (const [k, v] of Object.entries(ov)) {
    target[k] = v !== null && typeof v === 'object' && !Array.isArray(v) && typeof target[k] === 'object' && target[k] !== null ? applyOverrides(target[k], v) : structuredClone(v);
  }
  return target;
}

export class Scene {
  constructor(game, data = { name: 'scene', entities: [] }) {
    this.game = game;
    this.data = data;
    this.name = data.name;
    this.settings = data.settings ?? {};
    this.backend = game.backend ?? null;
    this.roots = [];
    this.scheduler = new Scheduler();
    this.running = false;
    this.alpha = 1;
    this.systems = []; // per-scene systems (event sheet runner): update/start/end/onDispatch/onCreated/onDestroyed
    this.#pending = [];
    this.#dead = new Set();
    this.#acc = 0;
  }
  #pending; #dead; #acc;

  *all() { for (const r of this.roots) yield* r.all(); }
  find(name) { for (const e of this.all()) if (e.name === name) return e; return null; }
  findById(id) { for (const e of this.all()) if (e.id === id) return e; return null; }
  findByTag(tag) { return [...this.all()].filter((e) => e.tags.includes(tag)); }

  /** Build entities (and their components/scripts) from scene data. Scripts are resolved via game.loadScript(path). */
  async build() {
    const made = [];
    for (const d of this.data.entities ?? []) made.push(await this.#make(d, null));
    this.roots.push(...made);
    for (const r of made) this.#wireConnections(r);
  }

  /** Inspector "Signals": when entity `e` emits `event`, call `method(data)` on the scripts of the target entity (default: itself). */
  #wireConnections(root) {
    for (const e of root.all()) {
      for (const c of e._connData) {
        if (!c.event || !c.method) continue;
        const target = c.target ? this.findById(c.target) : e;
        if (!target) { this.game.warn(`signal ${e.name}.${c.event}: target entity ${c.target} not found`); continue; }
        e.on(c.event, (d) => target.callScripts(c.method, d));
      }
    }
  }

  async #make(data, parent, { regenIds = false } = {}) {
    if (data.prefab?.path) data = await this.#expandPrefab(data);
    await this.backend?.prepare?.(data); // backend preloads textures/models referenced by this entity's components
    const e = new Entity({ ...data, id: regenIds || !data.id ? rid() : data.id }, this, parent);
    this.backend?.createNative?.(e);
    for (const c of e._compData) {
      const { type, ...rest } = c;
      if (rest.componentEnabled === false) continue; // Inspector checkbox off
      e.addComponent(type, rest);
    }
    for (const sd of e._scriptData) {
      if (!sd.path) continue; // a script added from code (entity.addScript) has no file: it cannot be rebuilt from data
      const Class = await this.game.loadScript(sd.path);
      if (!Class || !prepareScript(e, Class, (en, need) => sceneHooks.ensureRequired?.(en, need))) continue;
      const s = new Class(e, resolveAttributes(Class, sd.attributes, (m) => this.game.warn(m)));
      s._path = sd.path;
      e.scripts.push(s);
    }
    for (const bd of e._behaviorData) e.addBehavior(bd.type, bd.properties, bd.enabled);
    for (const cd of data.children ?? []) e.children.push(await this.#make(cd, e, { regenIds }));
    return e;
  }

  /** Prefab root entity; a variant (`variantOf` + `overrides`) is its base prefab's root with the overrides applied (nesting up to 8 deep). */
  async #prefabRoot(path, depth = 0) {
    const pf = await this.game.loadJSON(path);
    if (pf.variantOf && depth < 8) {
      const root = await this.#prefabRoot(pf.variantOf, depth + 1);
      return applyOverrides(root, pf.overrides ?? {});
    }
    return structuredClone(pf.root);
  }

  async #expandPrefab(data) {
    const root = await this.#prefabRoot(data.prefab.path);
    applyOverrides(root, data.prefab.overrides ?? {});
    // instance-level fields on the scene entity win over prefab root
    const merged = { ...root, id: data.id, transform: { ...root.transform, ...data.transform }, prefab: null };
    if (data.name) merged.name = data.name;
    if (data.enabled === false) merged.enabled = false;
    if (data.tags?.length) merged.tags = data.tags;
    return merged;
  }

  /** Spawn at runtime from entity JSON (ids regenerated). Lifecycle runs on the next frame boundary. */
  async spawnData(data, parent = null) {
    const e = await this.#make(data, parent, { regenIds: true });
    (parent ? parent.children : this.roots).push(e);
    this.#pending.push(e);
    this.#wireConnections(e);
    return e;
  }
  /** Spawn a prefab file: `scene.spawn('prefabs/bullet.prefab.json', { pos: [x,y,0], overrides: {...} })`. */
  async spawn(path, { pos, rot, scale, overrides, parent = null, name } = {}) {
    const transform = {};
    if (pos) transform.pos = pos;
    if (rot) transform.rot = rot;
    if (scale) transform.scale = scale;
    return this.spawnData({ name, transform, prefab: { path, overrides } }, parent);
  }

  /** init() all, then start() all, once the whole tree exists. */
  start() {
    const ents = [...this.all()];
    for (const e of ents) for (const s of e.scripts) { try { s.init?.(); this.#restore(s); } catch (err) { this.game.reportError(err, s, 'init'); } }
    this.running = true;
    for (const e of ents) this.#startEntity(e);
    this.#pending = [];
    for (const s of this.systems) { try { s.start?.(); } catch (err) { this.game.reportError(err, s, 'start'); } }
  }
  /** Persist: give a script that came back from the previous scene its old field values (after its own init()). */
  #restore(s) { if (s._restoreState) { Object.assign(s, s._restoreState); delete s._restoreState; } }
  #startEntity(e) {
    for (const s of e.scripts) {
      if (s._started) continue;
      s._started = true;
      if (e.enabled) { try { s.start?.(); s.onEnable?.(); } catch (err) { this.game.reportError(err, s, 'start'); } }
    }
  }

  /** Advance one frame. `dt` is real seconds; game.timeScale applied here. */
  tick(dt) {
    if (!this.running) return;
    dt = Math.min(dt, 0.25) * this.game.timeScale;
    this.game.time.delta = dt;
    this.game.time.elapsed += dt;
    this.game.input.beginFrame();
    const d = this.game.debug; let t = d ? d.now() : 0; // profiler: per-phase time, zero cost when the debugger is off
    const lap = (name) => { if (d) { const u = d.now(); d.phase(name, u - t); t = u; } };
    this.#flushSpawns();
    this.#acc += dt;
    for (let n = 0; this.#acc >= FIXED_DT && n < MAX_STEPS; n++, this.#acc -= FIXED_DT) {
      this.#each('fixedUpdate', FIXED_DT);
      this.backend?.step?.(FIXED_DT, this);
    }
    if (this.#acc > FIXED_DT * MAX_STEPS) this.#acc = 0;
    this.alpha = this.#acc / FIXED_DT; // how far the frame is between two physics steps (0..1): rigidbody interpolation uses it
    lap('fixed+physics');
    this.scheduler.update(dt);
    for (const s of this.systems) { try { s.update?.(dt); } catch (err) { this.game.reportError(err, s, 'update'); } }
    lap('systems');
    this.#each('update', dt);
    lap('scripts');
    for (const e of this.all()) for (const c of e.components) {
      if (!c.impl?.update) continue;
      if (d) { const u = d.now(); c.impl.update(c, dt); d.addComponent(c.type, d.now() - u); } else c.impl.update(c, dt);
    }
    lap('components');
    for (const e of [...this.all()]) if (e.enabled) for (const b of e.behaviors) if (b.enabled) { try { b.tick(dt); } catch (err) { this.game.reportError(err, b, 'tick'); } }
    lap('behaviors');
    this.#each('lateUpdate', dt);
    lap('late');
    this.#flushDeaths();
    lap('cleanup');
  }
  #each(method, dt) { for (const e of [...this.all()]) e.callScripts(method, dt); }
  #flushSpawns() {
    const p = this.#pending; this.#pending = [];
    for (const root of p) for (const e of root.all()) { for (const s of e.scripts) { try { s.init?.(); this.#restore(s); } catch (err) { this.game.reportError(err, s, 'init'); } } }
    for (const root of p) for (const e of root.all()) this.#startEntity(e);
    for (const root of p) for (const e of root.all()) for (const s of this.systems) s.onCreated?.(e);
  }

  /**
   * Move `e` under `newParent` (null = scene root) while the game runs. `keepWorld` (Unity's worldPositionStays, default true) keeps its place on screen:
   * the local transform is recomputed; false keeps the local numbers instead. Calls onTransformParentChanged / onTransformChildrenChanged on the scripts.
   * Backends do the maths (`beforeReparent` captures the world transform, `afterReparent` applies it under the new parent).
   */
  reparent(e, newParent = null, keepWorld = true) {
    if (e.destroyed || newParent?.destroyed) return false;
    for (let p = newParent; p; p = p.parent) if (p === e) { this.game.warn(`[nord] SetParent: ${e.name} cannot become a child of its own descendant ${newParent.name}`); return false; }
    const old = e.parent;
    if (old === newParent) return true;
    const token = this.backend?.beforeReparent?.(e, keepWorld);
    const from = old ? old.children : this.roots, i = from.indexOf(e);
    if (i >= 0) from.splice(i, 1);
    (newParent ? newParent.children : this.roots).push(e);
    e.parent = newParent;
    this.backend?.afterReparent?.(e, token, keepWorld);
    this.backend?.setEnabled?.(e, e.enabled);
    e.callScripts('onTransformParentChanged');
    old?.callScripts('onTransformChildrenChanged');
    newParent?.callScripts('onTransformChildrenChanged');
    return true;
  }

  destroyEntity(e) { if (!e.destroyed) { e.destroyed = true; this.#dead.add(e); } }
  #flushDeaths() {
    for (const e of this.#dead) {
      for (const d of [...e.all()].reverse()) {
        d.destroyed = true;
        for (const s of d.scripts) { try { s.onDestroy?.(); } catch (err) { this.game.reportError(err, s, 'onDestroy'); } }
        for (const c of d.components) c.impl?.destroy?.(c);
        this.backend?.destroyNative?.(d);
        for (const s of this.systems) s.onDestroyed?.(d);
        d.events.clear();
      }
      const list = e.parent ? e.parent.children : this.roots;
      const i = list.indexOf(e);
      if (i >= 0) list.splice(i, 1);
    }
    this.#dead.clear();
  }

  /** Physics/backends call this: `scene.dispatch(a, 'onCollisionEnter', b, contact)`. */
  dispatch(entity, method, ...args) {
    entity.callScripts(method, ...args);
    for (const s of this.systems) s.onDispatch?.(entity, method, args);
  }

  destroy() {
    for (const s of this.systems) { try { s.end?.(); } catch (err) { this.game.reportError(err, s, 'end'); } }
    for (const r of [...this.roots]) this.destroyEntity(r);
    this.#flushDeaths();
    this.scheduler.clear();
    this.running = false;
  }
}
