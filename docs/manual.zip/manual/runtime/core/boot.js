// Shared boot: wires Loader, Audio, UI and DOM input around a Game. Backends (phaser/babylon) call this, then drive game.tick(dt).
import { Game } from './game.js';
import { Loader } from './loader.js';
import { Audio } from './audio.js';
import { UI } from './ui.js';
import { attachDom } from './input.js';
import { attachDebugOverlay } from './debug.js';

/**
 * @param project parsed nord.project.json
 * @param opts { container: HTMLElement (position:relative), canvas, backend, files, storage, importScript, onError, seed, inlineOnly }
 */
export function createGame(project, opts = {}) {
  const loader = new Loader({ files: opts.files, inlineOnly: opts.inlineOnly });
  const game = new Game(project, {
    backend: opts.backend, storage: opts.storage, importScript: opts.importScript, onError: opts.onError, seed: opts.seed,
    fetchJSON: (p) => loader.json(p),
  });
  game.loader = loader;
  game.audio = new Audio(loader, { saveKey: `nord:${project.id}:audio`, storage: opts.storage ?? globalThis.localStorage });
  if (opts.container) {
    game.ui = new UI(opts.container, { skin: project.ui?.skin, theme: project.ui?.theme, fontBase: `${opts.libBase ?? '/vendor'}/fonts`, onSound: (n) => game.audio.play(`assets/audio/sfx/${n}.wav`, { bus: 'ui' }) });
    game.ui.events = game.events; game.ui.t = (k) => game.i18n?.t?.(k);
    game.audio.attach(globalThis.window);
  }
  if (opts.canvas) game._detachInput = attachDom(game.input, opts.canvas, globalThis.window, (x, y) => game.backend?.toWorld?.(x, y) ?? [x, y]);
  game.effects.attach(opts.canvas ?? null, opts.container ?? null);
  if (opts.container && (project.debug || /[?&]debug\b/.test(globalThis.location?.search ?? ''))) { game.enableDebug(); game._debugOverlay = attachDebugOverlay(game, opts.container); } // F9
  autoNet(game);
  game.preload = (paths) => game.backend?.preload?.(paths) ?? Promise.resolve();
  return game;
}

/**
 * Test helpers carried in the page URL (the editor's "Play N players" uses them): `?net=host:room` or `?net=join:room` (a guest retries
 * until the host exists) and `?netsim=latencyMs,jitterMs,loss` (loss 0..1) for the network simulator.
 */
function autoNet(game) {
  const q = new URLSearchParams(globalThis.location?.search ?? ''), n = q.get('net');
  if (!n) return;
  const [mode, room] = n.split(':');
  if (!/^[\w-]+$/.test(room ?? '')) return;
  const sim = q.get('netsim');
  if (sim) { const [latency, jitter, loss] = sim.split(',').map(Number); game.net.simulate({ latency, jitter, loss }); }
  const fail = (err) => game.warn?.(`[nord] ?net=${n}: ${err?.message ?? err}`);
  if (mode === 'host') game.net.host(room).catch(fail);
  else if (mode === 'join') { let tries = 0; const go = () => game.net.join(room, 4000).catch((err) => { if (++tries < 8) setTimeout(go, 1000); else fail(err); }); go(); }
}

/** Fill `container` with a sized stage div and return it. Dev pages call this: `const stage = makeStage(document.body, project)`. */
export function makeStage(parent, project) {
  const d = project.display ?? {};
  const stage = parent.ownerDocument.createElement('div');
  stage.style.cssText = `position:relative;width:100vw;height:100vh;overflow:hidden;background:${d.background ?? '#101418'}`;
  parent.appendChild(stage);
  return stage;
}

/** Surface fatal errors on screen so a broken script or missing asset is visible, not a silent blank canvas. Hot reload clears it. */
export function errorOverlay(container) {
  const doc = container.ownerDocument;
  const box = doc.createElement('pre');
  box.className = 'nord-error';
  box.style.cssText = 'position:absolute;left:0;right:0;bottom:0;max-height:40%;overflow:auto;margin:0;padding:10px 14px;background:#bf616acc;color:#fff;font:12px/1.4 var(--nord-font-code,ui-monospace,Menlo,monospace);display:none;z-index:99;white-space:pre-wrap';
  box.addEventListener('click', () => { box.style.display = 'none'; });
  container.appendChild(box);
  return {
    show(msg) { box.textContent = msg; box.style.display = 'block'; },
    clear() { box.style.display = 'none'; box.textContent = ''; },
    el: box,
  };
}

/** Editor "Run This Scene" (F6): the dev page URL carries `?scene=scenes/x.scene.json`; only plain relative scene paths are honoured. */
export function devSceneOverride(project) {
  const p = new URLSearchParams(globalThis.location?.search ?? '').get('scene');
  return p && /^[\w./-]+\.json$/.test(p) && !p.includes('..') && !p.startsWith('/') ? p : project.startScene;
}
